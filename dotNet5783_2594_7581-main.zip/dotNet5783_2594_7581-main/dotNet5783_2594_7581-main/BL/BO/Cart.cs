﻿using DO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO
{
    public class Cart
    {
         
            public string? CustomerName { get; set; } // property costumer name for the cart

            public string? CustomerEmail { get; set; }// property costumer email for the cart

            public string? CustomerAddress { get; set; }// property costumer address for the cart

            public List<OrderItem>? Items { get; set; }// property list of items in the cart

            public double TotalPrice { get; set; }// property costumer name for the cart

        public override string ToString()
        {//A method for printing customer data and product details in the cart
            String toString = "customerName: " + CustomerName + "\ncustomerEmail:" + CustomerEmail + "\ncustomersAddress" + CustomerAddress + "\nlistOfItems";
            Items?.ForEach(item => toString += "\nItem" + (Items.IndexOf(item) + 1) + ": " + item + "\n");
            toString += "totalPrice: " + TotalPrice;
            return toString;
        }
    }
    
}
