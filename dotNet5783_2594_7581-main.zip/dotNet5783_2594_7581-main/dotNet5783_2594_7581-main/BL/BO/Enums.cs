﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO;

public enum eCategory //enum for category types
{
    None,
    elegant,
    sport,
    flat,
    firstStep
    
}

public enum eOrderStatus //enum for order status types
{
    confirmedReservation,
    orderSent,
    providedToCustomer
}

public enum eOptions //enum for options types
{
    exit,
    cart,
    order,
    product
}
