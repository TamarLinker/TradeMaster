﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO;

public class DalException : Exception
{
    public DalException(Exception ex) : base("exception in dal", ex) { }

}

public class invalidId : Exception
{
    public override string Message => "invalid id";

}
public class invalidDetails : Exception
{
    public override string Message => "invalid details";

}
public class productExistInAnOrder : Exception
{
    public override string Message => "product exist in an order";

}
public class productNotExistInTheOrder : Exception
{
    public override string Message => "product not exist in the order";

}
public class QuantityInStockIsNotEnough : Exception
{
    public override string Message => "Quantity in stock is not enough";

}
public class orderAlreadyShipped : Exception
{
    public override string Message => "order already shipped";

}
public class orderAlreadyDelivered : Exception
{
    public override string Message => "order already delivered";

}
public class firstUpdateShipDate : Exception
{
    public override string Message => "first update ship date";

}
public class nullException : Exception
{
    public override string Message => "null Exception";

}