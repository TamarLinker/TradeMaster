﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO
{
    public class Order
    {
        public int ID { get; set; }// property id for the order

        public string? CustomerName { get; set; } // property costumer name for the order

        public string? CustomerEmail { get; set; }// property costumer email for the order

        public string? CustomerAdress { get; set; }// property costumer address for the order

        public System.DateTime OrderDate { get; set; }// property Order Date of the order

        public eOrderStatus Status { get; set; }// property Status of the order

        public System.DateTime ShipDate { get; set; }// property Ship Date of the order

        public System.DateTime DeliveryDate { get; set; }// property delivery Date of the order

        public  List<OrderItem>? Items { get; set; }// property list of items in the cart
        public double TotalPrice { get; set; } // property Total Price of the cart
        public override string ToString()
        {//A method for printing order data and product details in the order
            String toString = "customerName: " + CustomerName + "\ncustomerEmail:" + CustomerEmail + "\ncustomersAddress" + CustomerAdress + "\nlistOfItems";
            for (int i = 0; i < Items?.Count; i++)
            {
                toString += "\nItem" + (i + 1) + ": " + Items[i] + "\n";
            }
            toString += "totalPrice: " + TotalPrice;
            return toString;
        }

    }
    
}
