﻿using DO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO
{
    public class OrderForList
    {
        public int ID { get; set; }// property id of the Order For List

        public string? CustomerName { get; set; }// property costumer name for Order For List

        public eOrderStatus Status { get; set; }// property order ststus

        public int AmountOfItems { get; set; }// property Amount Of Items in the order

        public double TotalPrice { get; set; }// property Total Price of the order


        //A method for printing order data 
        public override string ToString() => $@"

        Order ID: {ID}, 
        Customer Name: {CustomerName},
        Status: {Status},
        Amount Of Items : {AmountOfItems},
    	Total Price: {TotalPrice}";
    }
}
