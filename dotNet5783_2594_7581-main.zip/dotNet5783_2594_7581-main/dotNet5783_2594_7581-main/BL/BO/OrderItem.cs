﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO
{
    public class OrderItem
    {
        public int ID { get; set; }// property id of order item
        public string? Name { get; set; }// property name of order item
        public int ProductID { set; get; }// property product id of order item
        public double Price { set; get; }// property price of order item
        public int Amount { set; get; }// property amount of order item
        public double TotalPrice { set; get; }// property Total Price of order item

        //A method for printing order item data 
        public override string ToString() => $@"
        ID={ID},
        name:{Name},
        Product ID={ProductID}, 
    	Price: {Price},
    	Amount : {Amount},
        total price:{TotalPrice}";

    }
}
