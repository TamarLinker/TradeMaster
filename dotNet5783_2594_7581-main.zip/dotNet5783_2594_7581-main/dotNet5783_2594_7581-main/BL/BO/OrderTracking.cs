﻿using DO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO
{
    public class OrderTracking
    {
        public int ID { get; set; }// property id of order tracking

        public eOrderStatus Status { get; set; }// property order status of order tracking

        public List<(DateTime,string)?>? TimeAndStatus { get; set; }
        
        public override string ToString()
        {//A method for printing order tracking data 
            String toString = "Product ID: " + ID + "\nStatus: " + Status  + "\nTime and status:\n"; 
            for (int i = 0; i < TimeAndStatus?.Count; i++)
            {
                toString += TimeAndStatus[i] + "\n";
            }
            return toString;
        }


    }
}
