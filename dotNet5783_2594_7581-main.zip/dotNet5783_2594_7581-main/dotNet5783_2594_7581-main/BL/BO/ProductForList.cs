﻿using DO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO
{
    public class ProductForList
    {
        public int ID { get; set; }//property id of product for list

        public string? Name { get; set; }//property name of product for list

        public double Price { get; set; }//property price of product for list

        public eCategory Category { get; set; }//property category of product for list

        //A method for printing product for list data 
        public override string ToString() => $@"
        Product ID:{ID}, 
        Name:{Name},
        Price: {Price},
        category : {Category}";
    }
}
