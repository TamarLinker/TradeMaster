﻿using DO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO
{
    public class ProductItem
    {
        public int ID { get; set; }//property id of product item

        public string? Name { get; set; }//property name of product item

        public double Price { get; set; }//property price of product item

        public eCategory Category { get; set; }//property category of product item
        public int Amount { get; set; }//property amount of product item

        public bool InStock { get; set; }//property inStock of product item

        //A method for printing product item data 
        public override string ToString() => $@"
        Product ID:{ID}, 
        Name:{Name},
        Price: {Price},
        category : {Category},
        Amount:{Amount},
    	Amount in stock: {InStock}";
    }
}
