﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BO;

namespace BlApi
{
    public interface ICart
    {//cart interface
        public Cart AddingAProduct(int productID,Cart cart);
        public Cart UpdatingtTheQuantityOfAProduct(int productID,Cart cart, int newAmount );
        public void  makeAnOrder(Cart cart);
    }
}
