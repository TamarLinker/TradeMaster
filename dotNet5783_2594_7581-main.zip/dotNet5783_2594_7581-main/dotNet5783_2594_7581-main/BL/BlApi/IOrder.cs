﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BO;

namespace BlApi
{
    public interface IOrder
    {//order interface
        public IEnumerable<OrderForList> OrderListRequest(Func<DO.Order, bool>? func = null);
        public Order OrderListResponse(int orderID);
        public Order OrderShippingUpdate(int orderID);
        public Order OrderDeliveryUpdate(int orderID);
        //public Order AddProductManagementScreen(int idOrder, int idProduct);
        public void ChangeProductQuantityByManager(int orderID, int productID,int newAmount);
        public OrderTracking orderTracking(int orderID);
        public int? selectOrder();
    }
}