﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BO;
using DO;

namespace BlApi
{
    public interface IProduct
    {//product interface
        public IEnumerable<ProductForList> ProductListRequest(Func<DO.Product, bool>? func = null);
        public IEnumerable<ProductItem> CatalogRequest(Func<DO.Product, bool>? func = null);
        public BO.Product ProductDetailsRequestDirector(int ProductId);
        public BO.Product ProductDetailsRequestBuyer(int ProductId);
        public void AddingAProduct(BO.Product product);
        public void ProductDletion(int ProductId);
        public void UpdateProductData(BO.Product product);
    }
}
