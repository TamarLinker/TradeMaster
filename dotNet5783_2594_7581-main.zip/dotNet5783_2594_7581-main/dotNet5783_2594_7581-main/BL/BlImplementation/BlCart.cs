﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using BlApi;
using BO;
using Dal;
using DalApi;
using DO;

namespace BlImplementation
{
    internal class BlCart: BlApi.ICart
    {
        //private IDal Dal = new DalList();
        private IDal? Dal = DalApi.Factory.Get();

        public BO.Cart AddingAProduct(int productID, BO.Cart cart)
        {//A method that adds a product to the shopping cart (for the catalog screen, product details screen)
            bool flag = false;
            DO.Product tempProduct;
            try
            {
                tempProduct = Dal?.Product.Get(productID) ?? throw new BO.nullException();
            }
            catch (ObjectNotFoundException e)
            {
                throw new BO.DalException(e);
            }
            catch (nullException e)
            {
                throw new BO.DalException(e);
            }
            if (cart.Items!=null)
            {
                var listOrderItem = from item in cart.Items
                                    where item.ProductID == productID
                                    select item;
                listOrderItem.ToList().ForEach(item =>
                {
                    if (tempProduct.InStock >= 1)
                    {
                        item.Amount += 1;
                        item.TotalPrice += item.Price;
                        cart.TotalPrice += tempProduct.Price;
                        flag = true;
                    }
                    else
                    {
                        throw new QuantityInStockIsNotEnough();
                    }
                });
            }            
            if (!flag)//if the product not exist in the cart or if the cart is empty
            {
                if (tempProduct.InStock > 0)
                {
                    BO.OrderItem tempOrderItem = new BO.OrderItem
                    {
                        ID = 0,
                        Name = tempProduct.Name,
                        Price = tempProduct.Price,
                        Amount = 1,
                        ProductID = tempProduct.ID,
                        TotalPrice = tempProduct.Price
                    };
                    List<BO.OrderItem> tempList = new List<BO.OrderItem>();
                    if (cart.Items != null)
                        tempList = cart.Items;
                    tempList.Add(tempOrderItem);
                    cart.Items = tempList;
                    cart.TotalPrice += tempOrderItem.Price;
                }
                else
                {
                    throw new QuantityInStockIsNotEnough();
                }
            }
            return cart;
        }
        public BO.Cart UpdatingtTheQuantityOfAProduct(int productID, BO.Cart cart, int newAmount)
        {//A method that updates the amount of a product in the shopping cart (for the shopping cart screen)

            BO.OrderItem orderItem= cart.Items?.Where(item => item.ProductID == productID).FirstOrDefault() ?? throw new nullException();
            try 
            {
                if (orderItem.ProductID != 0)
                {
                    if (newAmount == 0)
                    {
                        cart.TotalPrice -= orderItem.Price * orderItem.Amount;
                        cart.Items.Remove(orderItem);
                    }
                    else if (newAmount > orderItem.Amount)
                    {
                        DO.Product tempProduct = Dal?.Product.Get(productID)??throw new nullException();
                        if (tempProduct.InStock > newAmount)
                        {
                            cart.TotalPrice -= orderItem.Price * orderItem.Amount;
                            orderItem.Amount = newAmount;
                            orderItem.TotalPrice = orderItem.Price * newAmount;
                            cart.TotalPrice += orderItem.Price * newAmount;
                        }
                        else
                        {
                            throw new QuantityInStockIsNotEnough();
                        }
                    }
                    else if (newAmount < orderItem.Amount)
                    {
                        int tempAmount = orderItem.Amount - newAmount;
                        orderItem.Amount = newAmount;
                        orderItem.TotalPrice = orderItem.Price * newAmount;
                        cart.TotalPrice -= orderItem.Price * tempAmount;
                    }
                }
            }
            catch (ObjectNotFoundException e)
            {
                throw new BO.DalException(e);
            }
            catch (nullException e)
            {
                throw new BO.DalException(e);
            }
            return cart;
        }
        public void makeAnOrder(BO.Cart cart)
        {//A method for confirming an order basket / placing an order
         //(for the shopping basket screen or the order completion screen)
         bool flag=false;
            try
            {
                if (cart.CustomerName != "" && cart.CustomerAddress != "")
                {
                    if (cart.CustomerEmail != " ")
                    {
                        try
                        {
                            MailAddress checkEmail = new MailAddress(cart.CustomerEmail ?? throw new BO.nullException());

                        }
                        catch
                        {
                            throw new Exception("invalid email");
                        }
                    }               
                    DO.Order newOrder = new DO.Order
                    {
                        ID = 0,
                        CustomerAdress = cart.CustomerAddress,
                        CustomerEmail = cart.CustomerEmail,
                        CustomerName = cart.CustomerName,
                        DeliveryDate = DateTime.MinValue,
                        ShipDate = DateTime.MinValue,
                        OrderDate = DateTime.Now
                    };
                    int orderNumber = Dal?.Order.Add(newOrder)??throw new nullException();
                    cart?.Items?.ToList().ForEach(orderItem => {
                        DO.Product tempProduct = Dal.Product.Get(orderItem.ProductID);
                        if (orderItem.Amount > 0 && tempProduct.InStock >= orderItem.Amount)
                        {
                            DO.OrderItem tempOrderItem = new DO.OrderItem
                            {
                                ID = orderItem.ID,
                                Amount = orderItem.Amount,
                                OrderID = orderNumber,
                                Price = orderItem.Price,
                                ProductID = orderItem.ProductID
                            };
                            Dal.OrderItem.Add(tempOrderItem);
                            flag = true;
                            int tempInstock = tempProduct.InStock - orderItem.Amount;
                            tempProduct.InStock = tempInstock;
                            Dal.Product.Update(tempProduct);
                        }
                    }); 
                    if (!flag)
                    {
                        Dal.Order.Delete(orderNumber);
                    }
                }
                else
                {
                    throw new invalidDetails();
                }
            }
            catch (ObjectNotFoundException e)
            {
                throw new BO.DalException(e);
            }
            catch (ObjectAlreadyExist e)
            {
                throw new BO.DalException(e);
            }
            catch (nullException e)
            {
                throw e;
            }
        }
    }
}
