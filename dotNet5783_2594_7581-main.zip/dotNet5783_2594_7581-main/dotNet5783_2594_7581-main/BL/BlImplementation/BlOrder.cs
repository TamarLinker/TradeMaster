﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BlApi;
using BO;
using DalApi;
using DO;

namespace BlImplementation
{
    internal class BlOrder : BlApi.IOrder
    {
        //private IDal Dal = new DalList();
        private IDal Dal = DalApi.Factory.Get();
        int allOrderAmount = 0;
        double allOrderPrice = 0;
        BO.eOrderStatus eOrderStatus;
        public IEnumerable<BO.OrderForList> OrderListRequest(Func<DO.Order, bool>? func = null)
        {//A method for requesting a list of orders (for the admin screen)
            try
            {
                IEnumerable<DO.Order> allOrderList = Dal.Order.ReadAll(func);
                List<BO.OrderForList> allOrderForList = new List<BO.OrderForList>();
                allOrderList.ToList().ForEach(order => {
                    IEnumerable<DO.OrderItem> allOrderItemsByOrderId = Dal.OrderItem.ReadAll(item => item.OrderID == order.ID);
                    allOrderItemsByOrderId.ToList().ForEach(orderItem => {
                        allOrderAmount += orderItem.Amount;
                        allOrderPrice += orderItem.Amount * orderItem.Price;
                    });
                    if (order.DeliveryDate != DateTime.MinValue) 
                    {
                        eOrderStatus = BO.eOrderStatus.providedToCustomer;
                    }
                    else if (order.ShipDate != DateTime.MinValue)
                    {
                        eOrderStatus = BO.eOrderStatus.orderSent;
                    }
                    else
                    {
                        eOrderStatus = BO.eOrderStatus.confirmedReservation;
                    }
                    BO.OrderForList orderForList = new BO.OrderForList
                    {
                        ID = order.ID,
                        AmountOfItems = allOrderAmount,
                        CustomerName = order.CustomerName,
                        TotalPrice = allOrderPrice,
                        Status = eOrderStatus
                    };
                    allOrderForList.Add(orderForList);
                    allOrderAmount = 0;
                    allOrderPrice = 0;
                });
                return allOrderForList;
            }
            catch (ObjectAlreadyExist e)
            {
                throw new BO.DalException(e);
            }
            catch (ObjectNotFoundException e)
            {
                throw new BO.DalException(e);
            }
        }

        public BO.Order OrderListResponse(int orderID)
        {//Method for requesting order details (for manager screen and buyer screen)
            double totalPrice = 0;
            BO.eOrderStatus eOrderStatus;
            if (orderID > 0)
            {
                try
                {
                    DO.Order doOrder = Dal.Order.Get(orderID);
                    if (doOrder.DeliveryDate !=DateTime.MinValue)
                    {
                        eOrderStatus = BO.eOrderStatus.providedToCustomer;
                    }
                    else if (doOrder.ShipDate != DateTime.MinValue)
                    {
                        eOrderStatus = BO.eOrderStatus.orderSent;
                    }
                    else
                    {
                        eOrderStatus = BO.eOrderStatus.confirmedReservation;
                    }
                    IEnumerable<DO.OrderItem> doItems = Dal.OrderItem.ReadAll(item => item.OrderID == orderID);
                    List<BO.OrderItem> boItems = new List<BO.OrderItem>();
                    doItems.ToList().ForEach(orderItem =>
                    {
                        DO.Product tempProduct = Dal.Product.Get(orderItem.ProductID);
                        BO.OrderItem tempOrderItem = new BO.OrderItem
                        {
                            ID = tempProduct.ID,
                            Name = tempProduct.Name,
                            ProductID = orderItem.ProductID,
                            Price = orderItem.Price,
                            Amount = orderItem.Amount,
                            TotalPrice = orderItem.Amount * orderItem.Price
                        };
                        boItems.Add(tempOrderItem);
                        totalPrice += orderItem.Amount * orderItem.Price;
                    });
                    BO.Order allOrderDetails = new BO.Order 
                    { 
                        ID = doOrder.ID,
                        CustomerName = doOrder.CustomerName,
                        CustomerAdress = doOrder.CustomerAdress, 
                        CustomerEmail = doOrder.CustomerEmail,
                        DeliveryDate = doOrder.DeliveryDate??throw new nullException(), 
                        OrderDate = doOrder.OrderDate ?? throw new nullException(), 
                        ShipDate = doOrder.ShipDate ?? throw new nullException(), 
                        Status = eOrderStatus, 
                        Items = boItems, 
                        TotalPrice = totalPrice 
                    };
                    return allOrderDetails;
                }
                catch (ObjectAlreadyExist e)
                {
                    throw new BO.DalException(e);
                }
                catch (ObjectNotFoundException e)
                {
                    throw new BO.DalException(e);
                }
                catch(nullException e)
                {
                    throw e;
                }
            }
            throw new invalidId();
        }

        public BO.Order OrderShippingUpdate(int orderID)
        {//Method for updating an order shipment (admin order management screen)
            try
            {
                double totalPrice = 0;
                DO.Order doUpdateOrder = Dal.Order.Get(orderID);
                if (doUpdateOrder.ShipDate == DateTime.MinValue)
                {
                    doUpdateOrder.ShipDate = DateTime.Now;
                    Dal.Order.Update(doUpdateOrder);
                    IEnumerable<DO.OrderItem> doItems = Dal.OrderItem.ReadAll(item => item.OrderID == orderID);
                    List<BO.OrderItem> boItems = new List<BO.OrderItem>();
                    doItems.ToList().ForEach(orderItem =>
                    {
                        DO.Product tempProduct = Dal.Product.Get(orderItem.ProductID);
                        BO.OrderItem tempOrderItem = new BO.OrderItem
                        {
                            ID = 0,
                            Name = tempProduct.Name,
                            ProductID = orderItem.ProductID,
                            Price = orderItem.Price,
                            Amount = orderItem.Amount,
                            TotalPrice = orderItem.Amount * orderItem.Price
                        };
                        boItems.ToList().Add(tempOrderItem);
                        totalPrice += orderItem.Amount * orderItem.Price;
                    });
                    BO.Order boUpdateOrder = new BO.Order
                    {
                        ID = doUpdateOrder.ID, 
                        CustomerName = doUpdateOrder.CustomerName,
                        CustomerEmail = doUpdateOrder.CustomerEmail,
                        CustomerAdress = doUpdateOrder.CustomerAdress,
                        DeliveryDate = DateTime.MinValue, 
                        OrderDate = doUpdateOrder.OrderDate ?? throw new nullException(), 
                        ShipDate = DateTime.Now,
                        Status = BO.eOrderStatus.orderSent,
                        Items = boItems,
                        TotalPrice = totalPrice 
                    };
                    return boUpdateOrder;
                }
                else
                {
                    throw new orderAlreadyShipped();
                }
            }
            catch (ObjectAlreadyExist e)
            {
                throw new BO.DalException(e);
            }
            catch (ObjectNotFoundException e)
            {
                throw new BO.DalException(e);
            }

        }

        public BO.Order OrderDeliveryUpdate(int orderID)
        {//Order Delivery Update Method (Manager Order Management Screen)
            double totalPrice = 0;
            try
            {
                DO.Order doUpdateOrder = Dal.Order.Get(orderID);
                if (doUpdateOrder.DeliveryDate == DateTime.MinValue)
                {
                    if (doUpdateOrder.ShipDate > DateTime.MinValue)
                    {
                        doUpdateOrder.DeliveryDate = DateTime.Now;
                        Dal.Order.Update(doUpdateOrder);
                        IEnumerable<DO.OrderItem> doItems = Dal.OrderItem.ReadAll(item => item.OrderID == orderID);
                        List<BO.OrderItem> boItems = new List<BO.OrderItem>();
                        doItems.ToList().ForEach(orderItem =>
                        {
                            DO.Product tempProduct = Dal.Product.Get(orderItem.ProductID);
                            BO.OrderItem tempOrderItem = new BO.OrderItem
                            {
                                ID = 0,
                                Name = tempProduct.Name,
                                ProductID = orderItem.ProductID,
                                Price = orderItem.Price,
                                Amount = orderItem.Amount,
                                TotalPrice = orderItem.Amount * orderItem.Price
                            };
                            boItems.ToList().Add(tempOrderItem);
                            totalPrice += orderItem.Amount * orderItem.Price;
                        });
                        BO.Order boUpdateOrder = new BO.Order
                        {
                            ID = doUpdateOrder.ID,
                            CustomerName = doUpdateOrder.CustomerName,
                            CustomerEmail = doUpdateOrder.CustomerEmail,
                            CustomerAdress = doUpdateOrder.CustomerAdress,
                            DeliveryDate = DateTime.Now,
                            OrderDate = doUpdateOrder.OrderDate ?? throw new nullException(),
                            ShipDate = doUpdateOrder.ShipDate ?? throw new nullException(),
                            Status = BO.eOrderStatus.providedToCustomer,
                            Items = boItems,
                            TotalPrice = totalPrice
                        };
                        return boUpdateOrder;
                    }
                    else
                    {
                        throw new firstUpdateShipDate();
                    }
                }
                else
                {
                    throw new orderAlreadyDelivered();
                }
            }
            catch (ObjectAlreadyExist e)
            {
                throw new BO.DalException(e);
            }
            catch (ObjectNotFoundException e)
            {
                throw new BO.DalException(e);
            }
            catch (nullException e)
            {
                throw e;
            }

        }

        public void ChangeProductQuantityByManager(int orderID,int productID,int newAmount)
        {//A method for updating an order (for an administrator screen),
         //allows adding / downloading / changing the quantity of a product in an order by the administrator
            try
            {
                bool flag = false;
                DO.Order tempOrder = Dal.Order.Get(orderID);
                if (tempOrder.ShipDate == DateTime.MinValue)
                {
                    List<DO.OrderItem> tempOrderItemList = (List<DO.OrderItem>)Dal.OrderItem.ReadAll(item=>item.OrderID==orderID);
                    DO.OrderItem orderItem = tempOrderItemList.Find(orderItem => orderItem.ProductID == productID);
                    flag = true;
                    if (newAmount == 0)
                    {
                        tempOrderItemList.Remove(orderItem);
                    }
                    else if (newAmount > orderItem.Amount)
                    {
                        DO.Product tempProduct = Dal.Product.Get(productID);
                        if (tempProduct.InStock > newAmount)
                        {
                            DO.OrderItem tempOrderItem = new DO.OrderItem
                            {
                                ID = orderItem.ID,
                                Amount = newAmount,
                                OrderID = orderID,
                                Price = orderItem.Price,
                                ProductID = productID
                            };
                            Dal.OrderItem.Update(tempOrderItem);
                        }
                        else
                        {
                            throw new QuantityInStockIsNotEnough();
                        }
                    }
                    else
                    {
                        DO.Product tempProduct = Dal.Product.Get(productID);
                        DO.OrderItem tempOrderItem = new DO.OrderItem
                        {
                            ID = orderItem.ID,
                            Amount = newAmount,
                            OrderID = orderID,
                            Price = orderItem.Price,
                            ProductID = productID
                        };
                        Dal.OrderItem.Update(tempOrderItem);
                    }
                    if (!flag)
                    {
                        throw new productNotExistInTheOrder();
                    }
                }
                else
                {
                    throw new orderAlreadyShipped();
                }
            }
            catch (ObjectAlreadyExist e)
            {
                throw new BO.DalException(e);
            }
            catch (ObjectNotFoundException e)
            {
                throw new BO.DalException(e);
            }

        }

        public OrderTracking orderTracking(int orderID)
        {
            try
            {
                int orderStatus;
                DO.Order tempOrder = Dal.Order.Get(orderID);
                List<(DateTime,string)?> TimeAndDescriptionTemp =new List<(DateTime,string)?>();
                if(tempOrder.DeliveryDate>DateTime.MinValue)
                {
                    orderStatus = 2;
                    TimeAndDescriptionTemp.Add((tempOrder.OrderDate ?? throw new nullException(), "The order was created"));
                    TimeAndDescriptionTemp.Add((tempOrder.ShipDate ?? throw new nullException(), "The order was sent"));
                    TimeAndDescriptionTemp.Add((tempOrder.DeliveryDate ?? throw new nullException(), "The order was delivered"));
                }
                else if(tempOrder.ShipDate>DateTime.MinValue)
                {
                    orderStatus = 1;
                    TimeAndDescriptionTemp.Add((tempOrder.OrderDate ?? throw new nullException(), "The order was created"));
                    TimeAndDescriptionTemp.Add((tempOrder.ShipDate ?? throw new nullException(), "The order was sent"));
                }
                else
                {
                    orderStatus = 0;
                    TimeAndDescriptionTemp.Add((tempOrder.OrderDate ?? throw new nullException(), "The order was created"));
                }
                BO.OrderTracking tempOrderTracking = new BO.OrderTracking { ID = orderID, Status= (eOrderStatus)orderStatus, TimeAndStatus = TimeAndDescriptionTemp};
                return tempOrderTracking;
            }
            catch (BO.DalException ex)
            {

                throw new BO.DalException(ex);
            }
            catch (nullException e)
            {
                throw e;
            }
        }


        public int? selectOrder()
        {
            //IEnumerable<DO.Order>? orderToTreat=Dal?.Order.ReadAll().Where(item=>item.OrderDate!=DateTime.MinValue).OrderBy(item=>item.ShipDate!=DateTime.MinValue? item.ShipDate:item.DeliveryDate);
            //return orderToTreat.First().ID;
            IEnumerable<DO.Order>? orders = Dal.Order.ReadAll().Where(order => order.DeliveryDate == DateTime.MinValue).OrderBy(order => order.ShipDate != DateTime.MinValue ? order.ShipDate : order.OrderDate);
            if (orders.Count() > 0)
            {
                return orders.First().ID;
            }
            else
                return null;

        }
        //public void AddProductManagementScreen(int idOrder, int idProduct, int amountToAdd)
        //{

        //    bool flag = false;
        //    try
        //    {
        //        DO.Order order = new DO.Order();
        //        order = Dal.Order.Get(idOrder);
        //        List<DO.OrderItem> orderItems = (List<DO.OrderItem>)Dal.OrderItem.ReadOrderIDArr(order.ID);
        //        DO.Product productGet = Dal.Product.Get(idProduct); ;
        //        DO.OrderItem orderItem = new DO.OrderItem();
        //        if (productGet.InStock <= 0)
        //        {
        //            throw new Exception();
        //        }
        //        if (order.ShipDate == DateTime.MinValue)
        //        {
        //            foreach (DO.OrderItem item in orderItems)
        //            {
        //                if (item.ProductID == idProduct)
        //                {
        //                    if (productGet.InStock - item.Amount > amountToAdd)
        //                        throw new Exception();
        //                    flag = true;
        //                    orderItem.OrderID = idOrder;
        //                    orderItem.ID = item.ID;
        //                    orderItem.ProductID = item.ProductID;
        //                    orderItem.Amount = amountToAdd;
        //                    orderItem.Price += item.Price;
        //                    Dal.OrderItem.Update(orderItem);
        //                    DO.Product product = new DO.Product() { ID = productGet.ID, Price = productGet.Price, Category = productGet.Category, InStock = productGet.InStock - amountToAdd, Name = productGet.Name };
        //                    Dal.Product.Update(product);
        //                }
        //            }
        //            if (!flag)
        //            {
        //                if (productGet.InStock < amountToAdd)
        //                    throw new Exception();
        //                orderItem.OrderID = idOrder;
        //                orderItem.ProductID = idProduct;
        //                orderItem.Amount = amountToAdd;
        //                orderItem.Price = productGet.Price;
        //                Dal.OrderItem.Add(orderItem);
        //                DO.Product product = new DO.Product() { ID = productGet.ID, Price = productGet.Price, Category = productGet.Category, InStock = productGet.InStock - amountToAdd, Name = productGet.Name };
        //                Dal.Product.Update(product);
        //            }
        //        }
        //        else
        //        {
        //            throw new Exception();
        //        }
        //    }
        //    catch (BO.DalException ex)
        //    {
        //        throw new BO.DalException(ex);
        //    }
        //}
    }
}
