﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BlApi;
using BO;
using Dal;
using DalApi;
using DO;


namespace BlImplementation
{
    internal class BlProduct : BlApi.IProduct  
    {
        //private IDal Dal = new DalList();
        private IDal? Dal = DalApi.Factory.Get();
        public IEnumerable<BO.ProductForList> ProductListRequest(Func<DO.Product, bool>? func = null)
        //The method fetches the list of products from the data layer,
        //turns it into a list and returns it as a list of products for the admin screen
        {
            try
            {
                IEnumerable<DO.Product> allProductList = Dal?.Product.ReadAll(func) ?? throw new BO.nullException();
                List<BO.ProductForList> allProductForList = new List<BO.ProductForList>();
                allProductList.ToList().ForEach(product =>
                {
                    BO.ProductForList productForList = new BO.ProductForList
                    {
                        ID = product.ID,
                        Name = product.Name,
                        Category = (BO.eCategory)product.Category,
                        Price = product.Price
                    };
                    allProductForList.Add(productForList);
                });
                return allProductForList;
            }
            catch (ObjectAlreadyExist e)
            {
                throw new BO.DalException(e);
            }
            catch (ObjectNotFoundException e)
            {
                throw new BO.DalException(e);
            }
        }

        public IEnumerable<BO.ProductItem> CatalogRequest(Func<DO.Product, bool>? func = null)
        {//The method fetches the list of products from the data layer,
         //turns it into a list and returns it as a catalog for the client
            try
            {
                IEnumerable<DO.Product> allProductList = Dal?.Product.ReadAll(func) ?? throw new BO.nullException();
                List<BO.ProductItem> allProductItem = new List<BO.ProductItem>();
                allProductList.ToList().ForEach(product =>
                {
                    BO.ProductItem productItem = new BO.ProductItem
                    {
                        ID = product.ID,
                        Name = product.Name,
                        Category = (BO.eCategory)product.Category,
                        Price = product.Price,
                        InStock = (product.InStock > 0 ? true : false)
                    };
                    allProductItem.Add(productItem);
                });
                return allProductItem;
            }
            catch (ObjectAlreadyExist e)
            {
                throw new BO.DalException(e);
            }
            catch (ObjectNotFoundException e)
            {
                throw new BO.DalException(e);
            }

        }
        public BO.Product ProductDetailsRequestDirector(int ProductId)
        {//The method receives a product ID and returns the product object - its details for the manager
            if (ProductId > 0)
            {
                try
                {
                    DO.Product doProduct = Dal?.Product.Get(ProductId) ?? throw new BO.nullException();
                    BO.Product boProduct = new BO.Product 
                    { 
                        ID = doProduct.ID,
                        Name = doProduct.Name, 
                        Category = (BO.eCategory)doProduct.Category,
                        InStock = doProduct.InStock,
                        Price = doProduct.Price 
                    };
                    return boProduct;
                }
                catch (ObjectNotFoundException e)
                {
                    throw new BO.DalException(e);
                }
            }
            else
                throw new invalidId();
        }
        public BO.Product ProductDetailsRequestBuyer(int ProductId)
        {//The method receives a product ID and returns the product object - its details for the buyer
            if (ProductId > 0)
            {
                try
                {
                    DO.Product doProduct = Dal?.Product.Get(ProductId) ?? throw new BO.nullException();
                    BO.Product boProduct = new BO.Product
                    {
                        ID = doProduct.ID,
                        Name = doProduct.Name,
                        Category = (BO.eCategory)doProduct.Category,
                        InStock = doProduct.InStock,
                        Price = doProduct.Price
                    };
                    return boProduct;
                }
                catch (ObjectNotFoundException e)
                {
                    throw new BO.DalException(e);
                }
            }
            else
                throw new invalidId();
        }

        public void AddingAProduct(BO.Product product)
        {//The method receives a product object,
         //checks the correctness of the details and if the data is correct,
         //adds the product to the data layer
            if (product.ID > 0 && product.Name != "" && product.Price > 0 && product.InStock >= 0)
            {
                DO.Product doProduct = new DO.Product
                { 
                    ID = product.ID,
                    Name = product.Name, 
                    Category = (DO.eCategory)product.Category,
                    InStock = product.InStock, 
                    Price = product.Price };
                try
                {
                    Dal?.Product.Add(doProduct);
                }
                catch (ObjectAlreadyExist e)
                {
                    throw new BO.DalException(e);
                }
            }
            else
                throw new invalidDetails();
        }

        public void ProductDletion(int ProductId)
        {//The method receives a product object,
         //checks that the product does not appear in any orders,
         //and then deletes the product from the data layer
            try
            {
                IEnumerable<DO.OrderItem> allOrderList = Dal?.OrderItem.ReadAll() ?? throw new BO.nullException();
                DO.OrderItem orderItem = (from item in allOrderList
                                          where item.ProductID == ProductId
                                          select item).FirstOrDefault();
                if (orderItem.ProductID!=0)
                    throw new productExistInAnOrder();
                else
                    Dal.Product.Delete(ProductId);
            }
            catch (ObjectAlreadyExist e)
            {
                throw new BO.DalException(e);
            }
            catch (ObjectNotFoundException e)
            {
                throw new BO.DalException(e);
            }
        }
          
        public void UpdateProductData(BO.Product product)
        {//The method receives a product object,
         //checks the integrity of the data, and if the check was successful,
         //updates the data in the data layer
            if (product.ID > 0 && product.Name != "" && product.Price > 0 && product.InStock >= 0)
            {
                DO.Product doProduct = new DO.Product
                { 
                    ID = product.ID,
                    Name = product.Name,
                    Category = (DO.eCategory)product.Category, 
                    InStock = product.InStock, 
                    Price = product.Price };
                try
                {
                    Dal?.Product.Update(doProduct);
                }
                catch (ObjectNotFoundException e)
                {
                    throw new BO.DalException(e);
                }
            }
            else
                throw new invalidDetails();
        }

    }
}
