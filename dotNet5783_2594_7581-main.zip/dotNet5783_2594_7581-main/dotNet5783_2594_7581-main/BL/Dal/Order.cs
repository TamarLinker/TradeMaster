﻿namespace Dal
{
    internal class Order
    {
    }
}