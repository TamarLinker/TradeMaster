﻿using BlApi;
using BlImplementation;
using Dal;
using BO;
using DO;

namespace BlTest
{
    internal class Program
    {
        static private IBl ibl = new Bl();
        //static private DalList dalList = new DalList();
        private static DalApi.IDal? dalList = DalApi.Factory.Get();
        public static BO.Cart cartOptions(BO.Cart cart)
        {
            int optionChoice = 0;
            int productID=0;
            Console.WriteLine("enter 0 to exit\0 enter 1 to Add A Product\0 " +
                "enter 2 to Update The Quantity Of A Product\0 enter 3 to make An Order");
            int.TryParse(Console.ReadLine(), out optionChoice);
            switch (optionChoice)
            {
                case 0:
                    break;  
                case 1:
                    try
                    {
                        Console.WriteLine("enter product id");
                        int.TryParse(Console.ReadLine(), out productID);
                        cart = ibl.Cart.AddingAProduct(productID, cart);
                        Console.WriteLine(cart);
                    }
                    catch (DalException e)
                    {
                        Console.WriteLine(e.Message + " " + e.InnerException?.Message);
                    }
                    catch (QuantityInStockIsNotEnough e)
                    {
                        Console.WriteLine(e.Message);
                    }

                    break;
                case 2:
                    try
                    {
                        Console.WriteLine("enter product id & new amount");
                        int.TryParse(Console.ReadLine(),out productID);
                        int newAmount;
                        int.TryParse(Console.ReadLine(), out newAmount);
                        cart = ibl.Cart.UpdatingtTheQuantityOfAProduct(productID, cart, newAmount);
                        Console.WriteLine(cart);
                    }
                    catch (DalException e)
                    {
                        Console.WriteLine(e.Message + " " + e.InnerException?.Message);
                    }
                    catch (QuantityInStockIsNotEnough e)
                    {
                        Console.WriteLine(e.Message);
                    }
                    catch (invalidId e)
                    {
                        Console.WriteLine(e.Message);
                    }
                    break;
                case 3:
                    try
                    {
                        Console.WriteLine("enter name,email,address");
                        cart.CustomerName = Console.ReadLine();
                        cart.CustomerEmail = Console.ReadLine();
                        cart.CustomerAddress = Console.ReadLine();
                        ibl.Cart.makeAnOrder(cart);
                    }
                    catch (DalException e)
                    {
                        Console.WriteLine(e.Message + " " + e.InnerException?.Message);
                    }
                    catch (invalidDetails e)
                    {
                        Console.WriteLine(e.Message);
                    }
                    //email
                    catch(Exception e)
                    {
                        Console.WriteLine(e.Message);
                        
                    }
                    break;
                default:
                    break;
            }
            return cart;
        }
        public static void orderOptions()
        {
            int optionChoice = 0;
            int orderID = 0;
            BO.Order order;
            Console.WriteLine("enter 0 to exit\0 enter 1  to Order List Request\0 enter 2 to Order List Response\0" +
                " enter 3 to Order Shipping Update\0 enter 4 to Order Delivery Update\0 " +
                "enter 5 to update product in manager screen");
            int.TryParse(Console.ReadLine(),out optionChoice);
            switch (optionChoice)
            {
                case 0:
                    break;
                case 1:
                    try
                    {
                        IEnumerable<OrderForList> orderList = ibl.Order.OrderListRequest();
                        foreach (OrderForList item in orderList)
                        {
                            Console.WriteLine(item);
                        }
                    }
                    catch (DalException e)
                    {
                        Console.WriteLine(e.Message + " " + e.InnerException?.Message);
                    }
                    break;
                case 2:
                    try
                    {
                        Console.WriteLine("enter order id");
                        int.TryParse(Console.ReadLine(),out orderID);
                        order = ibl.Order.OrderListResponse(orderID);
                        Console.WriteLine(order);
                    }
                    catch (DalException e)
                    {
                        Console.WriteLine(e.Message + " " + e.InnerException?.Message);
                    }
                    catch (invalidId e)
                    {
                        Console.WriteLine(e.Message);
                    }
                    break;
                case 3:
                    try
                    {
                        Console.WriteLine("enter order id");
                        int.TryParse(Console.ReadLine(),out orderID);
                        order = ibl.Order.OrderShippingUpdate(orderID);
                        Console.WriteLine(order);
                    }
                    catch (DalException e)
                    {
                        Console.WriteLine(e.Message + " " + e.InnerException?.Message);
                    }
                    catch (orderAlreadyShipped e)
                    {
                        Console.WriteLine(e.Message);
                    }
                    break;
                case 4:
                    try
                    {
                        Console.WriteLine("enter order id");
                        int.TryParse(Console.ReadLine(), out orderID);
                        order = ibl.Order.OrderDeliveryUpdate(orderID);
                        Console.WriteLine(order); 
                    }
                    catch (DalException e)
                    {
                        Console.WriteLine(e.Message + " " + e.InnerException?.Message);
                    }
                    catch (orderAlreadyDelivered e)
                    {
                        Console.WriteLine(e.Message);
                    }
                    break;
                case 5:
                    try
                    {
                        Console.WriteLine("enter order id, product id, new amount");
                        int productID, newAmount;
                        int.TryParse(Console.ReadLine(),out orderID);
                        int.TryParse(Console.ReadLine(), out productID);
                        int.TryParse(Console.ReadLine(), out newAmount);
                        ibl.Order.ChangeProductQuantityByManager(orderID, productID, newAmount);
                    }
                    catch (DalException e)
                    {
                        Console.WriteLine(e.Message + " " + e.InnerException?.Message);
                    }
                    catch (orderAlreadyShipped e)
                    {
                        Console.WriteLine(e.Message);
                    }
                    catch (productNotExistInTheOrder e)
                    {
                        Console.WriteLine(e.Message);
                    }
                    break;
                default:
                    break;
            }
        }
        public static void productOptions()
        {
            int optionChoice = 0;
            int productID = 0;
            BO.Product product;
            Console.WriteLine("enter 0 to exit\0 enter 1 to Product List Request\0 enter 2 to Catalog Request\0" +
                " enter 3 to Product Details Request Director\0 " +
                "enter 4 to Product Details Request Buyer\0 enter 5 to Adding A Product\0" +
                " enter 6 to Product Dletion\0 enter 7 to Update Product Data");
            int.TryParse(Console.ReadLine(),out optionChoice);
            switch (optionChoice)
            {
                case 0:
                    break;
                case 1:
                    try
                    {
                        IEnumerable<ProductForList> productForList = ibl.Product.ProductListRequest();
                        foreach (ProductForList item in productForList) 
                        {
                            Console.WriteLine(item);
                        }
                    }
                    catch (DalException e)
                    {
                        Console.WriteLine(e.Message + " " + e.InnerException?.Message);
                    }
                    break;
                case 2:
                    try
                    {
                        IEnumerable<ProductItem> productItem = ibl.Product.CatalogRequest();
                        foreach (ProductItem item in productItem)
                        {
                            Console.WriteLine(item);
                        }
                       
                    }
                    catch (DalException e)
                    {
                        Console.WriteLine(e.Message + " " + e.InnerException?.Message);
                    }
                    break;
                case 3:
                    try
                    {
                        Console.WriteLine("enter product id");
                        int.TryParse(Console.ReadLine(),out productID);
                        product = ibl.Product.ProductDetailsRequestDirector(productID);
                        Console.WriteLine(product);
                    }
                    catch (DalException e)
                    {
                        Console.WriteLine(e.Message + " " + e.InnerException?.Message);
                    }
                    catch (invalidId e)
                    {
                        Console.WriteLine(e.Message);
                    }
                    break;
                case 4:
                    try
                    {
                        Console.WriteLine("enter product id");
                        int.TryParse(Console.ReadLine(),out productID);
                        product = ibl.Product.ProductDetailsRequestBuyer(productID);
                        Console.WriteLine(product);
                    }
                    catch (DalException e)
                    {
                        Console.WriteLine(e.Message + " " + e.InnerException?.Message);
                    }
                    catch (invalidId e)
                    {
                        Console.WriteLine(e.Message);
                    }
                    break;
                case 5:
                    try
                    {
                        Console.WriteLine("enter ID, Name,Price,Category,InStock");
                        int id,InStock; 
                        double Price;
                        int numCategory;
                        BO.eCategory category;
                        int.TryParse(Console.ReadLine(), out id);
                        string? Name=Console.ReadLine();
                        double.TryParse(Console.ReadLine(), out Price);
                        int.TryParse(Console.ReadLine(), out numCategory);
                        category = (BO.eCategory)numCategory;
                        int.TryParse(Console.ReadLine(), out InStock);    
                        product = new BO.Product 
                        {
                            ID = id,
                            Name = Name,
                            Price = Price,
                            Category = category,
                            InStock = InStock
                        };
                        ibl.Product.AddingAProduct(product);
                    }
                    catch (DalException e)
                    {
                        Console.WriteLine(e.Message + " " + e.InnerException?.Message);
                    }
                    catch (invalidDetails e)
                    {
                        Console.WriteLine(e.Message);
                    }

                    break;
                case 6:
                    try
                    {
                        Console.WriteLine("enter product id");
                        int.TryParse(Console.ReadLine(),out productID);
                        ibl.Product.ProductDletion(productID);
                    }
                    catch (DalException e)
                    {
                        Console.WriteLine(e.Message + " " + e.InnerException?.Message);
                    }
                    catch (productExistInAnOrder e)
                    {
                        Console.WriteLine(e.Message);
                    }

                    break;
                case 7:
                    try
                    {
                        Console.WriteLine("enter ID, Name,Price,Category,InStock");
                        int id7, numCategory7, InStock7;
                        int.TryParse(Console.ReadLine(), out id7);
                        string? Name7 = Console.ReadLine();
                        double Price7;
                        double.TryParse(Console.ReadLine(), out Price7);
                        BO.eCategory category7;
                        int.TryParse(Console.ReadLine(),out numCategory7);
                        category7 = (BO.eCategory)numCategory7;
                        int.TryParse(Console.ReadLine(), out InStock7);
                        
                        product = new BO.Product 
                        { 
                            ID = id7,
                            Name = Name7, 
                            Price = Price7,
                            Category = category7, 
                            InStock = InStock7
                        };
                        ibl.Product.UpdateProductData(product);
                    }
                    catch (DalException e)
                    {
                        Console.WriteLine(e.Message + " " + e.InnerException?.Message);
                    }
                    catch (invalidDetails e)
                    {
                        Console.WriteLine(e.Message);
                    }

                    break;
                default:
                    break;
            }
        }
        public static void Main(string[] args)
        {
            BO.Cart cart = new BO.Cart();
            cart.Items = new List<BO.OrderItem> () ;
            Console.WriteLine("enter 0 to exit\0 enter 1 to cart\0 enter 2 to order\0 enter 3 to product");
            int choiceNumber;
            int.TryParse(Console.ReadLine(),out choiceNumber);
            while (choiceNumber != 0)
            {
                switch (choiceNumber)
                {
                    case (int)BO.eOptions.cart:
                        cart=cartOptions(cart);
                        break;
                    case (int)BO.eOptions.order:
                        orderOptions();
                        break;
                    case (int)BO.eOptions.product:
                        productOptions();
                        break;
                    default:
                        break;
                }
                Console.WriteLine("enter 0 to exit\0 enter 1 to cart\0 enter 2 to order\0 enter 3 to product");
                int.TryParse(Console.ReadLine(), out choiceNumber);
            }
        }
    }
}