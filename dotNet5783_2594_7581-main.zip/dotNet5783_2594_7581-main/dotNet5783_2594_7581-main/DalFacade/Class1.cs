﻿
namespace DalFacade
{
    public class Class1
    {

    }
}
