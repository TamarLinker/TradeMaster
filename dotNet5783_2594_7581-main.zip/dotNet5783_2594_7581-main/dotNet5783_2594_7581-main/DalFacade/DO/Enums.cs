﻿
namespace DO;



    public enum eCategory
    {
        None,
        elegant,
        sport,
        flat,
        firstStep
    }
    public enum eOptions
    {
        exit,
        products,
        orders,
        orderItems
    }

    public enum eSubOptions
    {
        add,
        showId,
        showAll,
        update,
        delet,
        showOrderIdProductId,
        showAllOrderItems
    }




