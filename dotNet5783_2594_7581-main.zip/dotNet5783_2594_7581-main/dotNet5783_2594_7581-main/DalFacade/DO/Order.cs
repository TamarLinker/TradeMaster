﻿
using System;

namespace DO;

public struct Order
{
    public int ID { get; set; }// property id for the order

    public string CustomerName { get; set; }// property costumer name for the order

    public string CustomerEmail { get; set; }// property costumer email for the order

    public string CustomerAdress { get; set; }// property costumer address for the order

    public System.DateTime? OrderDate { get; set; }// property Order Date of the order

    public System.DateTime? ShipDate { get; set; }// property Ship Date of the order

    public System.DateTime? DeliveryDate { get; set; }// property delivery Date of the order

    //A method for printing order data
    public override string ToString() => $@"
        Order ID:{ID},
        Customer: Name:{CustomerName}, 
                  Email:{CustomerEmail},
    	          Adress: {CustomerAdress},
    	Order Date: {OrderDate},
    	ship Date: {ShipDate}
    	Delivery Date: {DeliveryDate}";

    public static implicit operator Order(Product v)
    {
        throw new NotImplementedException();
    }
}

