﻿using System;

namespace DO;

public struct OrderItem
{
    public int ID { get; set; }// property id of order item
    public int ProductID { set; get; }// property product id of order item
    public int OrderID { set; get; }// property order id of order item
    public double Price { set; get; }// property Price of order item
    public int Amount { set; get; }// property amount of order item

    //A method for printing order item data 
    public override string ToString() => $@"
        ID={ID},
        Order ID={OrderID}, 
        Product ID={ProductID}, 
    	Price: {Price},
    	Amount : {Amount}";

    public static implicit operator OrderItem(Product v)
    {
        throw new NotImplementedException();
    }
}