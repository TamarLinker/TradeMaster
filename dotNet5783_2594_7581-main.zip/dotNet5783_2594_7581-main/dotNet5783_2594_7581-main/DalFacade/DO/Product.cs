﻿namespace DO;

public struct Product
{
    public int ID { get; set; }//property id of product

    public string Name { get; set; }//property name of product

    public double Price { get; set; }//property price of product

    public eCategory Category { get; set; }//property category of product

    public int InStock { get; set; }//property instock of product

    //A method for printing product data 
    public override string ToString() => $@"
        Product ID:{ID}, 
        Name: {Name},
        Price: {Price},
        category : {Category},
    	Amount in stock: {InStock}";
}