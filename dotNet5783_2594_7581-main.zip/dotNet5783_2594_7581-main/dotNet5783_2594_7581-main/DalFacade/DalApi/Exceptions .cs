﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DalApi;

public class ObjectNotFoundException : Exception
{
    public override string Message => "object not found";

}
public class ObjectAlreadyExist : Exception
{
    public override string Message => "object already exist";

}
