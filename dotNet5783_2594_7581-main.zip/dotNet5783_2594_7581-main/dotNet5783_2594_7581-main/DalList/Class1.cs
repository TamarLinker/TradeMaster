﻿
namespace Dal
{
    class Class1
    {
        //public const int NUMPR = 5;
        //Random random= new Random();
        //public void f()
        //{
        //    random.NextInt64(10);
        //}
    }
}
