﻿//using DO;
//using static Dal.DataSource;

namespace Dal;
public class DalEnums
{

}