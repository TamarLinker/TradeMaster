﻿using DO;
using DalApi;
using System;
using System.Collections.Generic;
using static Dal.DataSource;
using System.Linq;
namespace Dal;

internal class DalOrder:IOrder
{
    public int Add(Order createOrder)
    {//A method that adds a new order to the data layer
        if(SIZE_ORDERS>_order.Count)
        {
            //createOrder.ID = Config.IDOrder;
            _order.Add(createOrder);
            return createOrder.ID;
        }
        throw new ObjectAlreadyExist();
    }

    public Order Get(int OrderID)
    {//A method that returns an order from the data layer according to the ID number it receives
        Order tempOrder = (from item in _order
                           let orderId= OrderID
                           where item.ID == orderId
                           select item).FirstOrDefault();
        if (tempOrder.ID == 0)
            throw new ObjectNotFoundException();
        return tempOrder;
    }

    public IEnumerable<DO.Order> ReadAll(Func<Order, bool> func = null)
    {//A method that returns all orders from the data layer
        if (_order == null)
        {
            throw new ObjectNotFoundException();
        }
        return func == null ? _order : _order.Where(func);
    }

    public void Delete(int OrderID)
    {//A method that deletes an order from the data layer based on an ID it receives
        try
        {
            Order order = Get(OrderID);
            _order.Remove(order);
        }
        catch (Exception)
        {
            throw new ObjectNotFoundException();
        }
    }

    public void Update(DO.Order UpdateOrder)
    {//A method that updates an order from the data layer according to the ID it receives
        try
        {
            Order order = Get(UpdateOrder.ID);
            int index = _order.IndexOf(order);
            _order[index] = UpdateOrder;
        }
        catch (Exception)
        {
            throw new ObjectNotFoundException();
        }
    }

    public Order GetObjectByCondition(Predicate<Order> func)
    {
        Order tempOrder= _order.Find(func);
        if (tempOrder.ID == 0)
            throw new ObjectNotFoundException();
        return tempOrder;
    }
}