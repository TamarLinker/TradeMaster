﻿
using static Dal.DataSource;
using System.Linq;
using System;
using DalApi;
using DO;
using System.Collections.Generic;
namespace Dal;

internal class DalOrderItem:IOrderItem
{
    public int Add(OrderItem createOrderItem)
    {//A method that adds an item to the cart if it is not already there
        if (SIZE_ORDERITEMS > _orderItem.Count)
        {
            //createOrderItem.ID = Config.IDOrderItem;
            _orderItem.Add(createOrderItem);
            return createOrderItem.ID;
        }
        throw new ObjectAlreadyExist();
    }

    public OrderItem Get(int OrderItemID)
    {//A method that returns an item

        OrderItem tempOrderItem = (from item in _orderItem
                                   where item.ID == OrderItemID
                                   select item).FirstOrDefault();
        if (tempOrderItem.ID == 0)
            throw new ObjectNotFoundException();
        return tempOrderItem;
    }

    //public OrderItem ReadOrderIDProductID(int OrderID, int ProductID)
    //{
    //    foreach (var item in DataSource._orderItem)
    //    {
    //        if (item.OrderID == OrderID && item.ProductID == ProductID)
    //            return item;
    //    }
    //    throw new ObjectNotFoundException();
    //}

  //  public IEnumerable<OrderItem> ReadOrderIDArr(int OrderID)
  //  {
  //      List<OrderItem> _newOrderItems = new List<OrderItem>();
  //      for (int i = 0; i < DataSource._orderItem.Count; i++)
		//{
  //          if (DataSource._orderItem[i].OrderID == OrderID)
  //          {
  //              _newOrderItems.Add(_orderItem[i]);
  //          }
		//}
  //      if(_newOrderItems==null)
  //          throw new ObjectNotFoundException();
  //      return _newOrderItems;    
  //  }

    public IEnumerable<OrderItem> ReadAll(Func<OrderItem, bool> func = null)
    {
        if (_orderItem == null)
        {
            throw new ObjectNotFoundException();
        }
        return func == null ? _orderItem : _orderItem.Where(func);
    }

    public void Delete(int OrderItemID)
    {
        try
        {
            OrderItem orderItem = Get(OrderItemID);
            _orderItem.Remove(orderItem);
        }
        catch (Exception)
        {
            throw new ObjectNotFoundException();
        }
    }

    public void Update(DO.OrderItem UpdateOrderItem)
    {
        try
        {
            OrderItem orderItem = Get(UpdateOrderItem.ID);
            int index = _orderItem.IndexOf(orderItem);
            _orderItem[index] = UpdateOrderItem;
        }
        catch (Exception)
        {
            throw new ObjectNotFoundException();
        }
    }
   
    public OrderItem GetObjectByCondition(Predicate<OrderItem> func)
    {
        OrderItem tempOrderItem = _orderItem.Find(func);
        if (tempOrderItem.ID == 0)
            throw new ObjectNotFoundException();
        return tempOrderItem;
    }

}