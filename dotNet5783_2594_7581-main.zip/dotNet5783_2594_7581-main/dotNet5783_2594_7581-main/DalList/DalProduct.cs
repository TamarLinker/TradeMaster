﻿using DO;
using System;
using DalApi;
using System.Collections.Generic;
using static Dal.DataSource;
using System.Linq;
namespace Dal;


internal class DalProduct:IProduct
{
    public int Add(Product createProduct)
    {//A method that adds an item to the basket if it is not already there
        if (SIZE_PRODUCTS > _products.Count)
        {
            //createProduct.ID = Config.RandomID();
            _products.Add(createProduct);
            return createProduct.ID;
        }
        throw new ObjectAlreadyExist();
    }

    public Product Get(int ProductID)
    {
        Product tempProduct = (from item in _products
                               where item.ID == ProductID
                               select item).FirstOrDefault();
        if (tempProduct.ID == 0)
            throw new ObjectNotFoundException();
        return tempProduct;
    }

    public IEnumerable<Product> ReadAll(Func<Product, bool> func = null)
    {   
        if (_products == null)
        {
            throw new ObjectNotFoundException();
        }
        return func == null ? _products : _products.Where(func);
    }

    public void Delete(int ProductID)
    {
        try
        {
            Product product = Get(ProductID);
            _products.Remove(product);
        }
        catch (Exception)
        {
            throw new ObjectNotFoundException();
        }
    }

    public void Update(DO.Product UpdateProduct)
    {
        try
        {
            Product product = Get(UpdateProduct.ID);
            int index = _products.IndexOf(product);
            _products[index] = UpdateProduct;
        }
        catch (Exception)
        {
            throw new ObjectNotFoundException();
        }
    }
   
    public Product GetObjectByCondition(Predicate<Product> func)
    {
        Product tempProduct = _products.Find(func);
        if (tempProduct.ID == 0)
            throw new ObjectNotFoundException();
        return tempProduct;
    }
}