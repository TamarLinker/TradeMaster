﻿using DalApi;
using DO;
using System;
using System.Collections.Generic;
namespace Dal;

internal static  class DataSource
{
   public static List<Product> _products { get; set; } = new List<Product>(); 
   public static List<Order> _order { get; set; } = new List<Order>(); 
   public static List<OrderItem> _orderItem { get; set; } = new List<OrderItem>();

    public const  int SIZE_ORDERS = 100;
    public const int SIZE_ORDERITEMS = 200;
    public const int SIZE_PRODUCTS = 50;
    /* static internal DO.Product[] _products = new DO.Product[50];
    static internal DO.Order[] _order = new DO.Order[100];
    static internal DO.OrderItem[] _orderItem = new DO.OrderItem[200];
    static readonly System.Random _random;*/

    static internal class Config 
    {
        public static readonly Random random = new Random();
        static public int RandomID()
        {
            int ID = random.Next(100000, 999999);
            for (int i = 0; i < _products.Count - 1; i++)
            {
                if (_products[i].ID == ID)
                {
                    RandomID();
                }
            }

            return ID;
        }
        static private int _IDOrder = 1;
        static private int _IDOrderItem = 1;
        static public int IDOrder
        {
            get { return _IDOrder++; }
        }

        static public int IDOrderItem
        {
            get { return _IDOrderItem++; }
        }

    }

    public static void AddOrder(DO.Order orderToAdd)
    {
        _order.Add(orderToAdd);
    }
    public static void AddOrderItem(DO.OrderItem orderItemToAdd)
    {
        _orderItem.Add(orderItemToAdd);
    }
    public static void AddProduct(DO.Product productToAdd)
    {
        _products.Add(productToAdd);
    }
    //static readonly System.Random _random;
    static DataSource()
    {
        s_Initialize();
    }
    static private void s_Initialize()
    {
        DO.Product tempProduct=new DO.Product();
        (string Name, eCategory Category,int InStock)[] products =  {
            ("run shoes",eCategory.sport,50),
            ("Training shoes",eCategory.sport,45),
            ("Orthopedic shoes",eCategory.sport,40),
            ("High heels shoes",eCategory.elegant,63),
            ("flat shoe",eCategory.flat,24),
            ("Medium heel shoe",eCategory.elegant,30),
            ("Moccasin shoes",eCategory.flat,88),
            ("slippers",eCategory.firstStep,92),
            ("Elegant shoes",eCategory.elegant,37),
            ("sandals",eCategory.firstStep,69),
         };
       // static readonly System.Random r;
        //System.Random r = new System.Random();
        for (int i = 0; i < 10; i++)
        {  
            
            tempProduct.ID = Config.RandomID();
            tempProduct.Name = products[i].Name;
            tempProduct.Price = (int)Config.random.NextInt64(30, 1000);
            tempProduct.Category = products[i].Category;
            tempProduct.InStock = products[i].InStock;
            AddProduct(tempProduct);
        }
        DO.Order tempOrder = new DO.Order();
        (string Name, string Email, string customerAdress)[] orders = {
            ("tamar1","tamar123@gmail.com","atavor1"),
            ("tamar2","tamar456@gmail.com","atavor2"),
            ("tamar3","tamar789@gmail.com","atavor3"),
            ("tamar4","tamar1011@gmail.com","atavor4"),
            ("tamar5","tamar1213@gmail.com","atavor5"),
            ("tamar6","tamar1415@gmail.com","atavor6"),
            ("tamar7","tamar1617@gmail.com","atavor7"),
            ("tamar8","tamar1819@gmail.com","atavor8"),
            ("tamar9","tamar2021@gmail.com","atavor9"),
            ("tamar10","tamar2223@gmail.com","atavor10"),
            ("tamar11","tamar2425@gmail.com","atavor11"),
            ("tamar12","tamar2627@gmail.com","atavor12"),
            ("tamar13","tamar2829@gmail.com","atavor13"),
            ("tamar14","tamar3031@gmail.com","atavor14"),
            ("tamar15","tamar3233@gmail.com","atavor15"),
            ("tamar16","tamar3435@gmail.com","atavor16"),
            ("tamar17","tamar3637@gmail.com","atavor17"),
            ("tamar18","tamar3839@gmail.com","atavor18"),
            ("tamar19","tamar4041@gmail.com","atavor19"),
            ("tamar20","tamar4243@gmail.com","atavor20")
            };
        for (int i = 0; i < 15; i++)
        {

            tempOrder.ID = Config.IDOrder;
            tempOrder.CustomerName = orders[i].Name;
            tempOrder.CustomerEmail = orders[i].Email;
            tempOrder.CustomerAdress = orders[i].customerAdress;

            tempOrder.OrderDate = DateTime.Now;
            int randDate1 = (int)Config.random.NextInt64(2,7);
            int randDate2 = (int)Config.random.NextInt64(1, 3);
            TimeSpan TimeOreder = new TimeSpan(randDate1, 0, 0, 0);
            //tempOrder.ShipDate = DateTime.MinValue;
            tempOrder.ShipDate = tempOrder.OrderDate?.Add(TimeOreder);
            TimeSpan TimeOrederDelivery = new TimeSpan(randDate2, 0, 0, 0);
            tempOrder.DeliveryDate = tempOrder.ShipDate?.Add(TimeOrederDelivery);
            AddOrder(tempOrder);

        }
        for (int i = 15; i < 20; i++)
        {
            tempOrder.ID = Config.IDOrder;
            tempOrder.CustomerName = orders[i].Name;
            tempOrder.CustomerEmail = orders[i].Email;
            tempOrder.CustomerAdress = orders[i].customerAdress;
            tempOrder.OrderDate = DateTime.Now;
            tempOrder.ShipDate = DateTime.MinValue;
            tempOrder.DeliveryDate = DateTime.MinValue;
            AddOrder(tempOrder);

        }

        DO.OrderItem tempOrderItem = new DO.OrderItem();
        for (int j = 0; j < 40; j++)
        {
            tempOrderItem.ID = Config.IDOrderItem;
            tempOrderItem.ProductID = _products[(int)Config.random.NextInt64(0, 10)].ID;
            tempOrderItem.Price = _products[(int)Config.random.NextInt64(0, 10)].Price;
            tempOrderItem.OrderID = _order[(int)Config.random.NextInt64(0, 20)].ID;
            tempOrderItem.Amount = (int)Config.random.NextInt64(1, 5);
            AddOrderItem(tempOrderItem);
        }
    }
}