﻿using System;
using DO;
using System.Collections.Generic;
namespace Dal;

public class Program
{
    private static DalApi.IDal dalList =DalApi.Factory.Get();
    //private static DalOrder DOrder = new DalOrder();
    //private static DalOrderItem DOrderItem = new DalOrderItem();
    //private static DalProduct DProduct = new DalProduct();
    static void showOptions(string choice)
    {
        Console.WriteLine("Enter 0 to exit \n" +
            "Enter 1 to add a {0} \n" +
                       "Enter 2 to  show {0} according to id \n" +
                       "Enter 3 to show all {0} \n" +
                       "Enter 4 to update {0}  \n" +
                       "Enter 5 to delete a {0} \n", choice);
        if (choice == "orderItems")
        {
            Console.WriteLine("Enter 6 to show {0} according to product id and order id" +
                     "Enter 7 to  show all {0} according to order id \n", choice);
        }
    }
    static void productOptions(string choice)
    {
        int choiceNumber = int.Parse(Console.ReadLine());
        while (choiceNumber != 0)
        {
            switch (choiceNumber)
            {
                case (int)eSubOptions.add:
                    int ID = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter name of product");
                    string name = Console.ReadLine();
                    Console.WriteLine("Enter category of product");
                    string category = Console.ReadLine();
                    Console.WriteLine("Enter price of product");
                    double price = double.Parse(Console.ReadLine());
                    Console.WriteLine("Enter InStock of product");
                    int InStock = int.Parse(Console.ReadLine());
                    Product newProduct = new Product();
                    newProduct.ID = ID;
                    newProduct.Name = name;
                    newProduct.Price = price;
                    newProduct.Category = (eCategory)(int.Parse(category));
                    newProduct.InStock = InStock;
                    Console.WriteLine(dalList.Product.Add(newProduct));
                    break;

                case (int)eSubOptions.showId:
                    Console.WriteLine("Enter ID of product");
                    ID = int.Parse(Console.ReadLine());
                    try
                    {
                        Console.WriteLine(dalList.Product.Get(ID));
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex);
                    }
                    break;

                case (int)eSubOptions.showAll:
                    try
                    {
                        IEnumerable<Product> products = dalList.Product.ReadAll();
                        foreach (DO.Product product in products)
                        {
                            Console.WriteLine(product);
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex);
                    }
                    break;

                case (int)eSubOptions.update:
                    Console.WriteLine("Enter ID of product");
                    ID = int.Parse(Console.ReadLine());
                    DO.Product tempProduct = new Product();
                    try
                    {
                        tempProduct = dalList.Product.Get(ID);
                        Console.WriteLine(tempProduct);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex);
                    }
                    Console.WriteLine("Enter name of product");
                    name = Console.ReadLine();
                    Console.WriteLine("Enter category of product");
                    category = Console.ReadLine();
                    Console.WriteLine("Enter price of product");
                    price = double.Parse(Console.ReadLine());
                    Console.WriteLine("Enter InStock of product");
                    InStock = int.Parse(Console.ReadLine());
                    DO.Product newProduct1 = new DO.Product();
                    newProduct1.ID = ID;
                    if (name == "")
                        newProduct1.Name = tempProduct.Name;
                    else
                        newProduct1.Name = name;
                    if (price == 0)
                        newProduct1.Price = tempProduct.Price;
                    else
                        newProduct1.Price = price;
                    if (category == "")
                        newProduct1.Category = tempProduct.Category;
                    else
                        newProduct1.Category = (eCategory)(int.Parse(category));
                    if (InStock == 0)
                        newProduct1.InStock = tempProduct.InStock;
                    else
                        newProduct1.InStock = InStock;
                    try
                    {
                        dalList.Product.Update(newProduct1);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex);
                    }
                    break;

                case (int)eSubOptions.delet:
                    Console.WriteLine("Enter ID of product");
                    ID = int.Parse(Console.ReadLine());
                    try
                    {
                        dalList.Product.Delete(ID);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex);
                    }

                    break;

                default:
                    break;
            }
            showOptions(choice);
            choiceNumber = int.Parse(Console.ReadLine());
        }
    }
    static void orderItemOptions(string choice)
    {
        int choiceNumber = int.Parse(Console.ReadLine());
        while (choiceNumber != 0)
        {
            switch (choiceNumber)
            {
                case (int)eSubOptions.add:
                    int ID = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Product ID of order item");
                    int ProductID = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Order ID of order item");
                    int OrderID = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter price of order item");
                    double Price = double.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Amount of order item");
                    int Amount = int.Parse(Console.ReadLine());
                    DO.OrderItem newOrderItem = new OrderItem();
                    newOrderItem.ID = ID;
                    newOrderItem.ProductID = ProductID;
                    newOrderItem.OrderID = OrderID;
                    newOrderItem.Price = Price;
                    newOrderItem.Amount = Amount;
                    Console.WriteLine(dalList.OrderItem.Add(newOrderItem));
                    break;

                case (int)eSubOptions.showId:
                    Console.WriteLine("Enter ID of order item");
                    ID = int.Parse(Console.ReadLine());
                    try
                    {
                        Console.WriteLine(dalList.OrderItem.Get(ID));
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex);
                    }
                    break;

                case (int)eSubOptions.showAll:
                    try
                    {
                        IEnumerable<OrderItem> orderItems = dalList.OrderItem.ReadAll();
                        foreach (DO.OrderItem orderItem in orderItems)
                        {
                            Console.WriteLine(orderItem);
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex);
                    }
                    break;

                case (int)eSubOptions.update:
                    Console.WriteLine("Enter ID of order item");
                    ID = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Product ID of order item");
                    DO.OrderItem tempOrderItem = new OrderItem();
                    try
                    {
                        tempOrderItem = dalList.OrderItem.Get(ID);
                        Console.WriteLine(tempOrderItem);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex);
                    }
                    ProductID = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Order ID of order item");
                    OrderID = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter price of order item");
                    Price = double.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Amount of order item");
                    Amount = int.Parse(Console.ReadLine());
                    DO.OrderItem newOrderItem1 = new OrderItem();
                    newOrderItem1.ID = ID;
                    if (ProductID == 0)
                        newOrderItem1.ProductID = tempOrderItem.ProductID;
                    else
                        newOrderItem1.ProductID = ProductID;
                    if (OrderID == 0)
                        newOrderItem1.OrderID = tempOrderItem.OrderID;
                    else
                        newOrderItem1.OrderID = OrderID;
                    if (Price == 0)
                        newOrderItem1.Price = tempOrderItem.Price;
                    else
                        newOrderItem1.Price = Price;
                    if (Amount == 0)
                        newOrderItem1.Amount = tempOrderItem.Amount;
                    else
                        newOrderItem1.Amount = Amount;
                    try
                    {
                        dalList.OrderItem.Update(newOrderItem1);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex);
                    }
                    break;

                case (int)eSubOptions.delet:
                    Console.WriteLine("Enter ID of order item");
                    ID = int.Parse(Console.ReadLine());
                    try
                    {
                        dalList.OrderItem.Delete(ID);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex);
                    }
                    break;


                case (int)eSubOptions.showOrderIdProductId:
                    Console.WriteLine("Enter Product Id");
                    int ProductId = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Order Id");
                    int OrderId = int.Parse(Console.ReadLine());
                    try
                    {
                        Console.WriteLine(dalList.OrderItem.GetObjectByCondition(item => item.OrderID == OrderId && item.ProductID == ProductId));
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex);
                    }
                    break;

                case (int)eSubOptions.showAllOrderItems:
                    Console.WriteLine("Enter Order Id");
                    OrderId = int.Parse(Console.ReadLine());
                    try
                    {
                        IEnumerable<OrderItem> oneOrderItems = dalList.OrderItem.ReadAll(item=>item.OrderID==OrderId);
                        foreach (DO.OrderItem oneOrderItem in oneOrderItems)
                        {
                            Console.WriteLine(oneOrderItem);
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex);
                    }
                    break;

                default:
                    break;
            }
            showOptions(choice);
            choiceNumber = int.Parse(Console.ReadLine());
        }
    }
    static void orderOptions(string choice)
    {
        int choiceNumber = int.Parse(Console.ReadLine());
        while (choiceNumber != 0)
        {
            switch (choiceNumber)
            {
                case (int)eSubOptions.add:
                    int ID = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Customer Name of order");
                    string CustomerName = Console.ReadLine();
                    Console.WriteLine("Enter Customer Email of order");
                    string CustomerEmail = Console.ReadLine();
                    Console.WriteLine("Enter Customer Adress of order");
                    string CustomerAdress = Console.ReadLine();
                    Console.WriteLine("Enter OrderDate of order");
                    System.DateTime? OrderDate = DateTime.Parse(Console.ReadLine());
                    Console.WriteLine("Enter ShipDate of order");
                    System.DateTime? ShipDate = DateTime.Parse(Console.ReadLine());
                    Console.WriteLine("Enter DeliveryDate of order");
                    System.DateTime? DeliveryDate = DateTime.Parse(Console.ReadLine());
                    Order newOrder = new Order();
                    newOrder.ID = ID;
                    newOrder.CustomerName = CustomerName;
                    newOrder.CustomerEmail = CustomerEmail;
                    newOrder.CustomerAdress = CustomerAdress;
                    newOrder.OrderDate = OrderDate;
                    newOrder.ShipDate = ShipDate;
                    newOrder.DeliveryDate = DeliveryDate;
                    Console.WriteLine(dalList.Order.Add(newOrder));
                    break;

                case (int)eSubOptions.showId:
                    Console.WriteLine("Enter ID of order");
                    ID = int.Parse(Console.ReadLine());
                    try
                    {
                        Console.WriteLine(dalList.Order.Get(ID));
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex);
                    }
                    break;

                case (int)eSubOptions.showAll:
                    try
                    {
                        IEnumerable <Order> orders = dalList.Order.ReadAll();
                        foreach (DO.Order order in orders)
                        {
                            Console.WriteLine(order);
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex);
                    }
                    break;

                case (int)eSubOptions.update:
                    Console.WriteLine("Enter ID of order");
                    ID = int.Parse(Console.ReadLine());
                    DO.Order tempOrder = new Order();
                    tempOrder = dalList.Order.Get(ID);
                    Console.WriteLine(tempOrder);
                    Console.WriteLine("Enter Customer Name of order");
                    CustomerName = Console.ReadLine();
                    Console.WriteLine("Enter Customer Email of order");
                    CustomerEmail = Console.ReadLine();
                    Console.WriteLine("Enter Customer Adress of order");
                    CustomerAdress = Console.ReadLine();
                    Console.WriteLine("Enter OrderDate of order");
                    OrderDate = DateTime.Parse(Console.ReadLine());
                    Console.WriteLine("Enter ShipDate of order");
                    ShipDate = DateTime.Parse(Console.ReadLine());
                    Console.WriteLine("Enter DeliveryDate of order");
                    DeliveryDate = DateTime.Parse(Console.ReadLine());
                    DO.Order newOrder1 = new Order();
                    newOrder1.ID = ID;
                    if (CustomerName == "")
                        newOrder1.CustomerName = tempOrder.CustomerName;
                    else
                        newOrder1.CustomerName = CustomerName;
                    if (CustomerEmail == "")
                        newOrder1.CustomerEmail = tempOrder.CustomerEmail;
                    else
                        newOrder1.CustomerEmail = CustomerEmail;
                    if (CustomerAdress == "")
                        newOrder1.CustomerAdress = tempOrder.CustomerAdress;
                    else
                        newOrder1.CustomerAdress = CustomerAdress;
                    if (OrderDate == null)
                        newOrder1.OrderDate = tempOrder.OrderDate;
                    else
                        newOrder1.OrderDate = OrderDate;
                    if (ShipDate == null)
                        newOrder1.ShipDate = tempOrder.ShipDate;
                    else
                        newOrder1.ShipDate = ShipDate;
                    if (DeliveryDate == null)
                        newOrder1.DeliveryDate = tempOrder.DeliveryDate;
                    else
                        newOrder1.DeliveryDate = DeliveryDate;
                    try
                    {
                        dalList.Order.Update(newOrder1);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex);
                    }
                    break;

                case (int)eSubOptions.delet:
                    Console.WriteLine("Enter ID of order");
                    ID = int.Parse(Console.ReadLine());
                    try
                    {
                        dalList.Order.Delete(ID);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex);
                    }
                    break;

                default:
                    break;
            }
            showOptions(choice);
            choiceNumber = int.Parse(Console.ReadLine());
        }
    }
    public static void Main(string[] args)
    {
        Console.WriteLine("enter 0 to exit\0 enter 1 to products\0 enter 2 to orders\0 enter 3 to order items");
        int choiceNumber = int.Parse(Console.ReadLine());
        string choice = "";
        while (choiceNumber != 0)
        {
            switch (choiceNumber)
            {
                case (int)eOptions.exit:
                    choice = "exit";
                    break;
                case (int)eOptions.products:
                    choice = "products";
                    showOptions(choice);
                    productOptions(choice);
                    break;
                case (int)eOptions.orders:
                    choice = "orders";
                    showOptions(choice);
                    orderOptions(choice);
                    break;
                case (int)eOptions.orderItems:
                    choice = "orderItems";
                    showOptions(choice);
                    orderItemOptions(choice);
                    break;
                default:
                    break;
            }
            Console.WriteLine("enter 0 to exit\0 enter 1 to products\0 enter 2 to orders\0 enter 3 to order items");
            choiceNumber = int.Parse(Console.ReadLine());
        }

    }

}