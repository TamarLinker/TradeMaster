﻿namespace DalXml
{
    public class Class1
    {

    }
}