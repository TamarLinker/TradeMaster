﻿using DalApi;
using DO;
using System;
//using DO;
using System.Linq;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace Dal;

internal class Order : IOrder
{
    public int Add(DO.Order order)
    { 
        if(order.ID == 0)
        {
            XElement? docConfig = XDocument.Load("../config.xml").Root;
            XElement? xmlConfig = docConfig?.Element("orderId");
            int id = Convert.ToInt32(xmlConfig?.Value);
            order.ID = id++;
            xmlConfig.Value = id.ToString();
            docConfig?.Save("../config.xml");
        }
        XDocument? doc = XDocument.Load("../orders.xml");
        XElement root = new XElement("Order");
        root.Add(new XElement("ID", order.ID));
        root.Add(new XElement("CustomerName", order.CustomerName));
        root.Add(new XElement("CustomerEmail", order.CustomerEmail));
        root.Add(new XElement("CustomerAdress", order.CustomerAdress));
        root.Add(new XElement("OrderDate", order.OrderDate));
        root.Add(new XElement("ShipDate", order.ShipDate));
        root.Add(new XElement("DeliveryDate", order.DeliveryDate));
        doc?.Element("Orders")?.Add(root);
        doc?.Save("../orders.xml");
        XDocument do1c = XDocument.Load("../orders.xml");
        return order.ID;
    }

    public DO.Order Get(int orderID)
    {
        XElement? doc = XDocument.Load("../orders.xml").Root;
        var xmlOrders = doc.Descendants("Order");
        XElement? xOrder = xmlOrders.ToList().Find(item => Convert.ToInt32(item.Element("ID")?.Value) == orderID);
        if (Convert.ToInt32(xOrder?.Element("ID")?.Value) == 0)
            throw new ObjectNotFoundException();
        DO.Order order = new DO.Order()
        {
            ID = Convert.ToInt32(xOrder?.Element("ID")?.Value),
            CustomerName = xOrder?.Element("CustomerName")?.Value,
            CustomerEmail = xOrder?.Element("CustomerEmail")?.Value,
            CustomerAdress = xOrder?.Element("CustomerAdress")?.Value,
            OrderDate = Convert.ToDateTime(xOrder?.Element("OrderDate")?.Value),
            ShipDate = Convert.ToDateTime(xOrder?.Element("ShipDate")?.Value),
            DeliveryDate = Convert.ToDateTime(xOrder?.Element("DeliveryDate")?.Value),
        };
        return order;
    }

    public DO.Order GetObjectByCondition(Predicate<DO.Order> func)
    {
        IEnumerable<DO.Order> lst = ReadAll();
        return lst.ToList().Find(func);
    }

    public IEnumerable<DO.Order> ReadAll(Func<DO.Order, bool>? func = null)
    {
        XElement? docConfig = XDocument.Load("../orders.xml").Root;
        List<DO.Order> orders = new List<DO.Order>();
        DO.Order order = new DO.Order();
        docConfig?.Elements().ToList().ForEach(item =>
        {
            order.ID = Convert.ToInt32(item.Element("ID")?.Value);
            order.CustomerName = item.Element("CustomerName")?.Value.ToString();
            order.CustomerEmail = item.Element("CustomerEmail")?.Value.ToString();
            order.CustomerAdress = item.Element("CustomerAdress")?.Value.ToString();
            order.OrderDate = Convert.ToDateTime(item?.Element("OrderDate")?.Value);
            order.ShipDate = Convert.ToDateTime(item?.Element("ShipDate")?.Value);
            order.DeliveryDate = Convert.ToDateTime(item?.Element("DeliveryDate")?.Value);
            orders.Add(order);
        });
        return func == null ? orders : orders.Where(func);
    }

    public void Update(DO.Order order)
    {
        Delete(order.ID);
        Add(order);
    }

    public void Delete(int orderID)
    {
        XDocument doc = XDocument.Load("../orders.xml");
        var xmlOrders = doc.Descendants("Order");
        xmlOrders.ToList().Find(item => Convert.ToInt32(item.Element("ID")?.Value) == orderID)?.Remove();
        doc.Save("../orders.xml");
    }
}

