﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dal;
using DalApi;
using DO;
using System.Xml.Linq;
using System.Xml.Serialization;

internal class OrderItem:IOrderItem
{
    public int Add(DO.OrderItem orderItem)
    {
        XElement? Config = XDocument.Load("../config.xml").Root;
        XElement? xmlOrderitemId = Config?.Element("orderItemId");
        int id = Convert.ToInt32(xmlOrderitemId?.Value);
        orderItem.ID = id++;
        xmlOrderitemId.Value = id.ToString();
        Config?.Save("../config.xml");

        List<DO.OrderItem> orderItemList=ReadAll().ToList();
        orderItemList?.Add(orderItem);
        StreamWriter white = new StreamWriter("../orderItems.xml");
        XmlSerializer ser = new XmlSerializer(typeof(List<DO.OrderItem>));
        ser.Serialize(white, orderItemList);
        white.Close();
        return orderItem.ID;
 
    }

    public DO.OrderItem Get(int orderItemID)
    {
        IEnumerable<DO.OrderItem> productList = ReadAll();
        DO.OrderItem tempOrderItem = productList.ToList().Find(item => item.ID == orderItemID);
        if (tempOrderItem.ID != 0)
            return tempOrderItem;
        throw new ObjectNotFoundException();
    }

    public DO.OrderItem GetObjectByCondition(Predicate<DO.OrderItem> func)
    {
        IEnumerable<DO.OrderItem> list = ReadAll();
        return list.ToList().Find(func);
    }

    public IEnumerable<DO.OrderItem> ReadAll(Func<DO.OrderItem, bool>? func = null)
    {

        //XmlSerializer ser = new XmlSerializer(typeof(List<DO.OrderItem>));
        //StreamReader read = new StreamReader("../orderItems.xml");
        //List<DO.OrderItem> productList = (List<DO.OrderItem>)ser.Deserialize(read);
        //read.Close();
        //return func == null ? productList : productList.Where(func);


        
        XmlSerializer ser = new XmlSerializer(typeof(List<DO.OrderItem>));
        StreamReader read = new StreamReader("../orderItems.xml");
        List<DO.OrderItem>?  productList = (List<DO.OrderItem>?)ser.Deserialize(read);
        //IEnumerable<DO.OrderItem>? productList1 = productList?.Where(func).ToList();
        read.Close();
        return func == null ? productList : productList.Where(func);

    }

    public void Update(DO.OrderItem OrderItem)
    {
        Delete(OrderItem.ID);
        Add(OrderItem);
    }

    public void Delete(int OrderItemID)
    {
        List<DO.OrderItem> productList = ReadAll().ToList();
        productList.Remove(Get(OrderItemID));
        StreamWriter writer = new StreamWriter(@"../xml/orderItems.xml");
        XmlSerializer ser = new XmlSerializer(typeof(List<DO.OrderItem>));
        ser.Serialize(writer, productList);
        writer.Close();
    }
}
