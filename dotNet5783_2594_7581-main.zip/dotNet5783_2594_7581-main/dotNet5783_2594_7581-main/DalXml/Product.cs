﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dal;
using DalApi;
using DO;
using System.ComponentModel;
using System.Reflection;
using System.Xml.Linq;
using System.Xml.Serialization;

internal class Product : IProduct
{
    public int Add(DO.Product product)
    {
        List<DO.Product> productList = ReadAll().ToList();
        DO.Product? tempProduct = productList?.ToList().Find(item => item.ID == product.ID);
        if (tempProduct?.ID == 0) 
        {
            productList?.Add(product);
            StreamWriter write = new StreamWriter("../products.xml");
            XmlSerializer ser = new XmlSerializer(typeof(List<DO.Product>));
            ser.Serialize(write, productList);
            write.Close();
        }
        else
        {
            throw new ObjectAlreadyExist();
        }
        return product.ID;
    }
    
   public DO.Product Get(int productID)
   {
        IEnumerable<DO.Product> productList = ReadAll();
        DO.Product tempProduct = productList.ToList().Find(item => item.ID == productID);
        if (tempProduct.ID != 0)
            return tempProduct;
        throw new Exception("not exist");
   }

    public DO.Product GetObjectByCondition(Predicate<DO.Product> func)
    {
        IEnumerable<DO.Product> lst = ReadAll();
        return lst.ToList().Find(func);
    }

    public IEnumerable<DO.Product> ReadAll(Func<DO.Product, bool>? func = null)
    {
        XmlSerializer ser = new XmlSerializer(typeof(List<DO.Product>));
        StreamReader read = new StreamReader("../products.xml");
        IEnumerable<DO.Product>? productList;
        productList = (IEnumerable<DO.Product>?)ser.Deserialize(read);
        read.Close();
        return (IEnumerable<DO.Product>)productList;
    }

    public void Update(DO.Product product)
    {
        Delete(product.ID);
        Add(product);
    }

    public void Delete(int productID)
    {
        List<DO.Product> productList = ReadAll().ToList();
        productList.Remove(Get(productID));
        StreamWriter writer = new StreamWriter("../products.xml");
        XmlSerializer ser = new XmlSerializer(typeof(List<DO.Product>));
        ser.Serialize(writer, productList);
        writer.Close();
    }
}