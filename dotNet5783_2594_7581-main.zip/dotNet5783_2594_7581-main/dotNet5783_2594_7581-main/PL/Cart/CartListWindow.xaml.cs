﻿using BlImplementation;
using BO;
using PL.Order;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using PL.Products;

namespace PL.Cart
{
    /// <summary>
    /// Interaction logic for CartListWindow.xaml
    /// </summary>
    public partial class CartListWindow : Window
    {

        BlApi.IBl bl = BlApi.Factory.Get();
        BO.Cart cart = ProductListWindow.cart;
        public CartListWindow()
        {
            InitializeComponent();
            DataContext = cart.Items;
        }

        private void cartListView_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            BO.OrderItem item = (BO.OrderItem)((ListView)sender).SelectedItem;
            new CartWindow(item).ShowDialog();
            cartListView.Items.Refresh();
        }

        private void submitOrderButton_Click(object sender, RoutedEventArgs e)
        {
            new CustomerDetailsWindow().ShowDialog();
            try
            {
                bl.Cart.makeAnOrder(cart);
                MessageBox.Show("The order confirmed");
               
                this.Close();
            }
            catch (DalException ex)
            {
                MessageBox.Show(ex.Message + " " + ex.InnerException?.Message);
            }
            catch (invalidDetails ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (nullException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch
            {
                MessageBox.Show("invalid email");
            }
        }

        private void cartListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
