﻿using BlApi;
using BO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using PL.Products;

namespace PL.Cart
{
    /// <summary>
    /// Interaction logic for CartWindow.xaml
    /// </summary>
    /// 
    
    public partial class CartWindow : Window
    {
        BlApi.IBl bl = BlApi.Factory.Get();
        int productId;
        BO.Cart cart=ProductListWindow.cart;
        public CartWindow(BO.OrderItem orderItem)
        {
            InitializeComponent();
            productId=orderItem.ProductID;
            DataContext=orderItem;  
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int newAmount = Convert.ToInt32(amountTextbox.Text);
                cart = bl.Cart.UpdatingtTheQuantityOfAProduct(productId, cart, newAmount);
                this.Close();
            }
            catch (DalException ex)
            {
                MessageBox.Show(ex.Message + " " + ex.InnerException?.Message);
            }
            catch (QuantityInStockIsNotEnough ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void deleteProductFromCartButton_Click(object sender, RoutedEventArgs e)
        {
            cart = bl.Cart.UpdatingtTheQuantityOfAProduct(productId, cart, 0);
            this.Close();
        }
    }
}
