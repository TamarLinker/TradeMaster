﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Windows;
//using System.Windows.Controls;
//using System.Windows.Data;
//using System.Windows.Documents;
//using System.Windows.Input;
//using System.Windows.Media;
//using System.Windows.Media.Imaging;
//using System.Windows.Shapes;
//using System.IO;
//using System.Xml.Linq;
//using System.Xml.Serialization;


//namespace PL
//{
//    /// <summary>
//    /// Interaction logic for DataSource.xaml
//    /// </summary>
//    public partial class DataSource : Window
//    {
//        public DataSource()
//        {
//            InitializeComponent();
//            List<DO.Product> products = new();
//            List<DO.Order> orders = new();
//            List<DO.OrderItem> orderItems = new();
//            Tuple<string, double, DO.eCategory>[] arrProducts = {
//            new Tuple<string, double, DO.eCategory>("run shoes", 100, DO.eCategory.sport),
//            new Tuple<string, double, DO.eCategory>("Training shoes", 70, DO.eCategory.sport),
//            new Tuple<string, double, DO.eCategory>("Orthopedic shoes", 150, DO.eCategory.sport),
//            new Tuple<string, double, DO.eCategory>("High heels shoes", 200, DO.eCategory.elegant),
//            new Tuple<string, double, DO.eCategory>("flat shoe", 220, DO.eCategory.flat),
//            new Tuple<string, double, DO.eCategory>("Medium heel shoe", 250,DO.eCategory.elegant),
//            new Tuple<string, double, DO.eCategory>("Moccasin shoes", 300, DO.eCategory.flat),
//            new Tuple<string, double, DO.eCategory>("slippers", 270, DO.eCategory.firstStep),
//            new Tuple<string, double, DO.eCategory>("Elegant shoes", 500, DO.eCategory.elegant),
//            new Tuple<string, double, DO.eCategory>("sandals", 400, DO.eCategory.firstStep)
//        };
//            //add 20 Customers
//            Tuple<string, string, string>[] arrOrders = {
//         new  Tuple<string, string, string>("David", "David@gmail.com", "David st."),
//         new  Tuple<string, string, string>("Chaya", "Chaya@gmail.com", "David st."),
//         new  Tuple<string, string, string>("Ayala", "Ayala@gmail.com", "David st."),
//         new  Tuple<string, string, string>("Efrat", "Efrat@gmail.com", "David st."),
//         new  Tuple<string, string, string>("Tamar", "Tamar@gmail.com", "David st."),
//         new  Tuple<string, string, string>("Miri", "Miri@gmail.com", "David st."),
//         new  Tuple<string, string, string>("Adas", "Adas@gmail.com", "David st."),
//         new  Tuple<string, string, string>("Noa", "Noa@gmail.com", "David st."),
//         new  Tuple<string, string, string>("Feigy", "Feigy@gmail.com", "David st."),
//         new  Tuple<string, string, string>("Rachel", "Rachel@gmail.com", "David st."),
//         new  Tuple<string, string, string>("Malcky", "Malcky@gmail.com", "David st."),
//         new  Tuple<string, string, string>("Shira", "Shira@gmail.com", "David st."),
//         new  Tuple<string, string, string>("Itamar", "Itamar@gmail.com", "David st."),
//         new  Tuple<string, string, string>("Jonatan", "Jonatan@gmail.com", "DaDavid st.vid"),
//         new  Tuple<string, string, string>("Ariel", "Ariel@gmail.com", "David st."),
//         new  Tuple<string, string, string>("Michal", "Michal@gmail.com", "David st."),
//         new  Tuple<string, string, string>("Binyamin", "Binyamin@gmail.com", "David st."),
//         new  Tuple<string, string, string>("Ester", "Ester@gmail.com", "David st."),
//         new  Tuple<string, string, string>("Chava", "Chava@gmail.com", "David st."),
//         new  Tuple<string, string, string>("Sara", "Sara@gmail.com", "David st.")
//        };
//            Random _random = new();
//            for (int i = 0; i < 10; i++)                                  //add products by the randoaly numbers
//            {
//                DO.Product p = new()
//                {
//                    ID = (int)_random.NextInt64(100000, 999999),
//                    Name = arrProducts[(int)_random.NextInt64(0, 9) % 10].Item1,
//                    Price = arrProducts[(int)_random.NextInt64(100000, 999999) % 10].Item2,
//                    InStock = (int)_random.NextInt64(0, 20),
//                    Category = arrProducts[(int)_random.NextInt64(100000, 999999) % 10].Item3
//                };
//                products.Add(p);
//            }

//            for (int i = 0; i < 30; i++)
//            {
//                DO.Order o = new()
//                {
//                    ID = 0,
//                    CustomerName = arrOrders[i % 20].Item1,
//                    CustomerEmail = arrOrders[i % 20].Item2,
//                    CustomerAdress = arrOrders[i % 20].Item3,
//                    OrderDate = DateTime.Now
//                };
//                TimeSpan t = new((int)_random.NextInt64(1, 3), 0, 0, 0);
//                o.ShipDate = (i % 20) % 5 != 0 ? o.OrderDate.Value.Add(t) : DateTime.MinValue;
//                t = new TimeSpan((int)_random.NextInt64(3, 7), 0, 0, 0);
//                o.DeliveryDate = ((i % 20) % 3 != 0 || (i % 20) % 4 != 0) & (i % 20) % 5 != 0 ? o.ShipDate.Value.Add(t) : DateTime.MinValue;
//                orders.Add(o);
//            }

//            for (int i = 0; i < 20; i++)
//            {
//                int var = (int)_random.NextInt64(1, 10);
//                DO.OrderItem oI = new()
//                {
//                    ID = 0,
//                    ProductID = products?[var].ID ?? throw new Exception(),
//                    OrderID = orders?[i].ID ?? throw new Exception(),
//                    Amount = var,
//                    Price = products[var].Price
//                };
//                orderItems.Add(oI);
//            }

//            //var arrXmlOrders = from p in orders
//            //                   select new XElement("orders",
//            //                                           new XAttribute("ID", p.ID),
//            //                                           new XAttribute("CustomerName", p.CustomerName ?? throw new BO.nullException()),
//            //                                           new XAttribute("CustomerEmail", p.CustomerEmail),
//            //                                           new XAttribute("CustomerAdress", p.CustomerAdress),
//            //                                           new XAttribute("OrderDate", p.OrderDate),
//            //                                           new XAttribute("ShipDate", p.ShipDate),
//            //                                           new XAttribute("DeliveryDate", p.DeliveryDate)
//            //      );
//            //XElement? xmlProduct = XDocument.Load(@"../orders.xml").Root;
//            StreamWriter write = new StreamWriter("../products.xml");
//            XmlSerializer ser = new XmlSerializer(typeof(List<DO.Product>));
//            ser.Serialize(write, products);
//            write.Close();
//            StreamWriter write2 = new StreamWriter("../orderItems.xml");
//            XmlSerializer ser2 = new XmlSerializer(typeof(List<DO.OrderItem>));
//            ser2.Serialize(write2, orderItems);
//            write2.Close();
//            InitializeComponent();
//        }
//    }
//}
