﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using PL.Products;
using PL.Order;

namespace PL.Order
{
    /// <summary>
    /// Interaction logic for OrderListWindow.xaml
    /// </summary>
    public partial class OrderListWindow : Window
    {
        BlApi.IBl bl=BlApi.Factory.Get();
        public OrderListWindow()
        {
            InitializeComponent();
            List<BO.OrderForList> tempOrderForList = (List<BO.OrderForList>)bl.Order.OrderListRequest();
            DataContext = tempOrderForList;
        }

        private void OrderListView_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            BO.OrderForList order = (BO.OrderForList)OrderListView.SelectedItem;
            new OrderWindow(order.ID, "orderList").ShowDialog();
            //OrderListView.ItemsSource = bl.Order.OrderListRequest();

           
        }

        private void OrderListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
