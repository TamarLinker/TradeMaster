﻿using BlImplementation;
using BO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PL.Order
{
    /// <summary>
    /// Interaction logic for OrderTrackingWindow.xaml
    /// </summary>
    public partial class OrderTrackingWindow : Window
    {
        BlApi.IBl bl = BlApi.Factory.Get();
        //int orderTrackingId;


        //public OrderTracking OrderTracking { get; set; } = new OrderTracking();
        int id;
        public OrderTrackingWindow()
        {
            InitializeComponent();
        }

        private void okButton_Click(object sender, RoutedEventArgs e)
        {
             id =Convert.ToInt32( orderIdTextBox.Text);
            try
            {
                BO.OrderTracking orderTracking = bl.Order.orderTracking(id);
                statusTextBox.Text = orderTracking.Status.ToString();
                timeAndStatusListView.ItemsSource = orderTracking.TimeAndStatus;
            }
            catch (DalException ex)
            {
                MessageBox.Show(ex.Message + " " + ex.InnerException?.Message);
            }
        }

        private void showMoreDetailsButton_Click(object sender, RoutedEventArgs e)
        {
            new OrderWindow(id, "orderTracking").Show();
        }

        private void timeAndStatusListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
