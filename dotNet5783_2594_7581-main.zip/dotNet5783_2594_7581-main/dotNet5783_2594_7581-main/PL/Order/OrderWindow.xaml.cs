﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BlApi;
using BO;

namespace PL.Order
{
    /// <summary>
    /// Interaction logic for OrderWindow.xaml
    /// </summary>
    public partial class OrderWindow : Window
    {
        BlApi.IBl bl = BlApi.Factory.Get();
        int ID;
        BO.Order order;
        public string orderTypeProperty { get; set; }
        public OrderWindow(int ID,string orderType)
        {
            InitializeComponent();
            this.ID = ID;
            order=bl.Order.OrderListResponse(ID);

           // OrderItemsListView.ItemsSource = order.Items;
            orderTypeProperty = orderType;
            DataContext = new { order = order, orderTypeProperty = orderTypeProperty };
        }

        private void updateShipDateButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                order = bl.Order.OrderShippingUpdate(ID);
                DataContext = new { order = order, orderTypeProperty = orderTypeProperty };
            }
            catch (orderAlreadyShipped ex)
            {
                MessageBox.Show(ex.Message + " " + ex.InnerException?.Message);
            }
            catch (DalException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void updateDelieveryDateButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                order = bl.Order.OrderDeliveryUpdate(ID);
                DataContext = new { order = order, orderTypeProperty = orderTypeProperty };
            }
            catch (DalException ex)
            {
                MessageBox.Show(ex.Message + " " + ex.InnerException?.Message);
            }
            catch (orderAlreadyDelivered ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (firstUpdateShipDate ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void StatusTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
    public class NotBooleanToVisibilityConverter : IValueConverter
    {
        public object Convert(
        object value,
        Type targetType,
        object parameter,
        CultureInfo culture)
        {
            if (value.ToString()== "orderTracking")
            {
                return Visibility.Hidden;
            }
            else
            {
                return Visibility.Visible;
            }
        }
        public object ConvertBack(
        object value,
        Type targetType,
        object parameter,

        CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

}
