﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using PL.Cart;

namespace PL.Products
{
    /// <summary>
    /// Interaction logic for ProductListWindow.xaml
    /// </summary>
    public partial class ProductListWindow : Window
    {
        BlApi.IBl bl = BlApi.Factory.Get();
        public string whoEnterProperty { get; set; }
        public static BO.Cart cart = new BO.Cart();
        public Array categoryProperty { get; set; }
        List<BO.ProductItem> tempProductItem;
        List<BO.ProductForList> tempProductForList;
        public ProductListWindow(string whoEnter)
        {
            InitializeComponent();
            if (whoEnter=="admin")
            {
                tempProductItem = (List<BO.ProductItem>)bl.Product.CatalogRequest();
                ProductListview.ItemsSource = tempProductItem;
                GroupDescription();
                whoEnterProperty = whoEnter;
                DataContext = new { whoEnterProperty = whoEnterProperty, categoryProperty = categoryProperty, tempProductForList = tempProductItem };
            }
            if (whoEnter == "customer")
            {
                 tempProductForList = (List<BO.ProductForList>)bl.Product.ProductListRequest();
                ProductListview.ItemsSource = tempProductForList;
                GroupDescription();
                whoEnterProperty = whoEnter;
                DataContext = new { whoEnterProperty = whoEnterProperty, categoryProperty = categoryProperty, tempProductForList = tempProductForList };
            }
        }
        public void GroupDescription()
        {
            categoryProperty = Enum.GetValues(typeof(BO.eCategory));
            CollectionView view = (CollectionView)CollectionViewSource.GetDefaultView(ProductListview.ItemsSource);
            PropertyGroupDescription groupDescription = new PropertyGroupDescription("Category");
            view.GroupDescriptions.Add(groupDescription);
        }
        private void CategorySelector_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (((BO.eCategory)CategorySelector.SelectedItem).ToString()=="None")
                tempProductForList = (List<BO.ProductForList>)bl.Product.ProductListRequest();
            else
                tempProductForList = (List<BO.ProductForList>)bl.Product.ProductListRequest(item => item.Category.ToString() == ((BO.eCategory)CategorySelector.SelectedItem).ToString());
            DataContext = new { whoEnterProperty = whoEnterProperty, categoryProperty = categoryProperty, tempProductForList = tempProductForList };
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            new ProductWindow("add").ShowDialog();
            ProductListview.ItemsSource = bl.Product.CatalogRequest();
            GroupDescription();
        }

        private void ProductListview_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
        }
     
        private void ProductListview_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if(whoEnterProperty == "customer")
            {
                BO.ProductForList product = (BO.ProductForList)ProductListview.SelectedItem;
                new ProductWindow("customer",product).ShowDialog();
            }
            else if (whoEnterProperty == "admin")
            {
                BO.ProductItem product = (BO.ProductItem)ProductListview.SelectedItem;
                new ProductWindow("update", product).ShowDialog();
                ProductListview.ItemsSource = bl.Product.CatalogRequest();
                GroupDescription();
            }
        }

        private void moveToCartButton_Click(object sender, RoutedEventArgs e)
        {
            new CartListWindow().Show();
        }
    }
    public class NotBooleanToVisibilityAdminEnterConverter : IValueConverter
    {
        public object Convert(
        object value,
        Type targetType,
        object parameter,
        CultureInfo culture)
        {
            if (value.ToString() =="admin")
            {
                return Visibility.Visible;
            }
            else
            {
                return Visibility.Hidden;
            }
        }
        public object ConvertBack(
        object value,
        Type targetType,
        object parameter,

        CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
    public class NotBooleanToVisibilityCustomerEnterConverter : IValueConverter
    {
        public object Convert(
        object value,
        Type targetType,
        object parameter,
        CultureInfo culture)
        {
            if (value.ToString() == "customer")
            {
                return Visibility.Visible;
            }
            else
            {
                return Visibility.Hidden;
            }
        }
        public object ConvertBack(
        object value,
        Type targetType,
        object parameter,

        CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}