﻿using BlApi;
using BO;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PL.Products
{
    /// <summary>
    /// Interaction logic for ProductWindow.xaml
    /// </summary>
    public partial class ProductWindow : Window
    {
        BlApi.IBl bl = BlApi.Factory.Get();
        BO.Cart cart=ProductListWindow.cart;
        BO.ProductItem? productItem = new ProductItem();
        public string actionProperty { get; set; }
        public Array categoryProperty { get; set; }
        BO.Product tempProduct = new BO.Product();
        public ProductWindow(string action)
        {
            InitializeComponent();
            categoryProperty = Enum.GetValues(typeof(BO.eCategory));
            actionProperty = action;
            DataContext = new { tempProduct = tempProduct,actionProperty = actionProperty,categoryProperty};
        }
        public ProductWindow(string action, BO.ProductForList? productToUpdate = null)
        {
            InitializeComponent();
            categoryProperty = Enum.GetValues(typeof(BO.eCategory));
            if (productToUpdate != null)
            {
                tempProduct = bl.Product.ProductDetailsRequestBuyer(productToUpdate.ID);
            }
            actionProperty = action;
            DataContext = new { tempProduct = tempProduct, actionProperty = actionProperty, categoryProperty };
        }
        public ProductWindow(string action, BO.ProductItem? productItem = null)
        {
            InitializeComponent();
            categoryProperty = Enum.GetValues(typeof(BO.eCategory));
            if (productItem != null)
            {
                tempProduct = bl.Product.ProductDetailsRequestBuyer(productItem.ID);
                    //this.productItem = productItem;
            }
            actionProperty = action;
            DataContext = new { tempProduct = tempProduct, actionProperty = actionProperty, categoryProperty };
        }
        private void ConfirmAddProductButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (actionProperty == "add")
                {
                    bl.Product.AddingAProduct(tempProduct);
                    MessageBox.Show("The item has been successfully added");
                    Close();
                }
                if (actionProperty == "update")
                {
                    bl.Product.UpdateProductData(tempProduct);
                    MessageBox.Show("The item has been successfully updated");
                    Close();
                }
            }
            catch (DalException ex)
            {
                MessageBox.Show(ex.Message + " " + ex.InnerException?.Message);
            }
            catch (invalidDetails ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void priceTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            
        }

        private void addToCartButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (tempProduct != null)
                {
                    cart = bl.Cart.AddingAProduct(tempProduct.ID, cart);
                }
                
                this.Close();
            }
            catch (DalException ex)
            {
                MessageBox.Show(ex.Message + " " + ex.InnerException?.Message);
            }
            catch (QuantityInStockIsNotEnough ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }

    public class NotBooleanToVisibilityAdminConverter : IValueConverter
    {
        public object Convert(
        object value,
        Type targetType,
        object parameter,
        CultureInfo culture)
        {
            if (value.ToString() == "add"|| value.ToString() == "update")
            {
                return Visibility.Visible;
            }
            else
            {
                return Visibility.Hidden;
            }
        }
        public object ConvertBack(
        object value,
        Type targetType,
        object parameter,

        CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
    public class NotBooleanToVisibilityCustomerConverter : IValueConverter
    {
        public object Convert(
        object value,
        Type targetType,
        object parameter,
        CultureInfo culture)
        {
            if (value.ToString() =="customer")
            {
                return Visibility.Visible;
            }
            else
            {
                return Visibility.Hidden;
            }
        }
        public object ConvertBack(
        object value,
        Type targetType,
        object parameter,

        CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
    public class NotBooleanToIsEnabledConverter : IValueConverter
    {
        public object Convert(
        object value,
        Type targetType,
        object parameter,
        CultureInfo culture)
        {
            if (value.ToString() == "customer")
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        public object ConvertBack(
        object value,
        Type targetType,
        object parameter,

        CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
    public class NotBooleanToIsEnabledIDConverter : IValueConverter
    {
        public object Convert(
        object value,
        Type targetType,
        object parameter,
        CultureInfo culture)
        {
            if (value.ToString() == "add")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public object ConvertBack(
        object value,
        Type targetType,
        object parameter,

        CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

}
