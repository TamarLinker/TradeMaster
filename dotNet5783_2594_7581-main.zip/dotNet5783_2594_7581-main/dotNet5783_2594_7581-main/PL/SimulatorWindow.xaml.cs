﻿using BlApi;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static System.Net.Mime.MediaTypeNames;
using NSimulator;
using BO;

namespace PL
{
    /// <summary>
    /// Interaction logic for SimulatorWindow.xaml
    /// </summary>
    public partial class SimulatorWindow : Window
    {
        BackgroundWorker Worker;
        private Stopwatch stopWatch;
        private bool isTimerRun;
        bool flagClose = true;
        BO.Order? order;

        public SimulatorWindow()
        {
            InitializeComponent();
            Worker = new BackgroundWorker();
            Worker.DoWork += Worker_DoWork;
            Worker.ProgressChanged += Worker_ProgressChanged;
            Worker.RunWorkerCompleted += Worker_RunWorkerCompleted;
            Worker.WorkerReportsProgress = true;
            Worker.WorkerSupportsCancellation = true;
            Worker.RunWorkerAsync();
            stopWatch = new Stopwatch();
            if (!isTimerRun)
            {
                stopWatch.Restart();
                isTimerRun = true;
            }
        }

        private void Worker_DoWork(object? sender, DoWorkEventArgs e)
        {
            while (!Worker.CancellationPending)
            {
                try
                {
                    CSimulator.SetSimulatorStart();
                }
                catch (DalException ex)
                {
                    MessageBox.Show(ex.Message + " " + ex.InnerException?.Message);
                }
                catch (orderAlreadyDelivered ex)
                {
                    MessageBox.Show(ex.Message);
                }
                catch (firstUpdateShipDate ex)
                {
                    MessageBox.Show(ex.Message);
                }
                catch (orderAlreadyShipped ex)
                {
                    MessageBox.Show(ex.Message);
                }
                
                CSimulator.changeStatus += StatusChanged;
                CSimulator.EndSimulatorEvent += EndSimulator;
                while (isTimerRun)
                {
                    Worker.ReportProgress(1);
                    Thread.Sleep(1000);
                }
            }
        }

        private void Worker_ProgressChanged(object? sender, ProgressChangedEventArgs e)
        {
            string timerText = stopWatch.Elapsed.ToString();
            timerText = timerText.Substring(0, 8);
            timerTextBlock.Text = timerText;
            if (order is null)
                statusLabel.Content = "please wait...";
            else
                statusLabel.Content = "Order number" + order.ID.ToString();
        }

        private void Worker_RunWorkerCompleted(object? sender, RunWorkerCompletedEventArgs e)
        {
            CSimulator.changeStatus -= StatusChanged;
            CSimulator.EndSimulatorEvent -= EndSimulator;
            isTimerRun = false;
        }

        public void StatusChanged(BO.Order? tempOrder, string newStatus, DateTime startTime, DateTime endTime)
        {
            order = tempOrder;
            Dispatcher.Invoke(() =>
            {
                txtSimulator.Text = $"order number" + order?.ID.ToString() + "\n" +
                $"Previous status: " + order?.Status.ToString() + "\n" +
                $"Current status: " + newStatus + "\n" +
                $"start change at: " + startTime + "\n" +
                $"end change at: " + endTime;
            });
        }

        private void stopTimerButton_Click(object? sender=null, RoutedEventArgs? e=null)
        {
            

        }

        public void EndSimulator(DateTime end, string reasonStop)
        {
            Dispatcher.Invoke(() =>
            {
                if (reasonStop != "")
                {
                    MessageBox.Show("The simulator finished: " + end.ToString() + "\n" + "because: " + reasonStop);
                    stopTimerButton_Click();
                }
            });
        }

        private void MainWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = flagClose;
        }

        private void StopSimulator_Click(object sender, RoutedEventArgs e)
        {
            CSimulator.stopSimulation();
            flagClose = false;
            Worker.CancelAsync();
            Close();
        }
    }
}
