﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BO;
using BlApi;
using DalApi;

namespace NSimulator
{

    public static class CSimulator
    {
        public delegate void ChangeStatus(BO.Order order, string newStatus, DateTime prev, DateTime next);
        public delegate void EndSimulator(DateTime end, string reason = "");
        public static event ChangeStatus? changeStatus = null;
        public static event EndSimulator? EndSimulatorEvent = null;
        volatile private static bool stopRequest = false;
        public static bool IsRunning { get; set; } = false;
        public static void SetSimulatorStart()
        {
            IsRunning = true;
            Thread thread = new Thread(startSimulation);
            stopRequest = false;
            thread.Start();
        }
        public static void startSimulation()
        { 
            Random random = new Random();
            IBl bl = BlApi.Factory.Get();
            string newStatus = "", reasonStop = "";
            while (!stopRequest)
            {
                try
                {
                    int? orderID = bl?.Order.selectOrder();
                    if (orderID == null)
                    {
                        stopRequest = true;
                        reasonStop = "There are no more orders to update";
                        break;
                    }
                    BO.Order? orderDetails = bl?.Order.OrderListResponse(Convert.ToInt32(orderID));
                    if (stopRequest) break;
                    int randomTime = random.Next(2000, 10000);
                    BO.eOrderStatus? prevState = orderDetails?.Status;
                    DateTime startTime = DateTime.Now;
                    Thread.Sleep(randomTime);
                    if (orderDetails?.Status == BO.eOrderStatus.confirmedReservation)
                    {
                        bl?.Order.OrderShippingUpdate(Convert.ToInt32(orderID));
                        newStatus = "The order sent";
                    }
                    else
                    {
                        bl?.Order.OrderDeliveryUpdate(Convert.ToInt32(orderID));
                        newStatus = "The order Provided to Customer";
                    }
                    DateTime endTime = DateTime.Now;
                    changeStatus?.Invoke(orderDetails ?? throw new Exception(), newStatus, startTime, endTime);
                    Thread.Sleep(1000);
                }
                catch (orderAlreadyShipped e)
                {
                    throw new orderAlreadyShipped();
                }
                catch (firstUpdateShipDate e)
                {
                    throw new firstUpdateShipDate();
                }
                catch (orderAlreadyDelivered e)
                {
                    throw new orderAlreadyDelivered();
                }
                catch (DalException e)
                {
                    throw new BO.DalException(e);
                }
            }
            EndSimulatorEvent?.Invoke(DateTime.Now, reasonStop);
        }

        public static void stopSimulation()
        {
            stopRequest = true;
            IsRunning = false;
        }
    }
}
