﻿using System;
namespace Stage0
{
    partial class Program
    {
        static void Main(string[] args)
        {
            Welcome7581();
            Welcome2594();
            Console.ReadKey();
        }
        static partial void Welcome2594();
        private static void Welcome7581()
        {
            Console.WriteLine("enter your name: ");
            string name = Console.ReadLine();
            Console.WriteLine("{0}, welcome to my first console appliatin", name);
        }
    }
}